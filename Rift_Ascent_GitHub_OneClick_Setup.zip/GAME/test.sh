#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p screenshots
gcc -std=c11 -O1 -g -Wall -Wextra -Wno-misleading-indentation -fsanitize=address,undefined -fno-omit-frame-pointer src/game.c src/render.c src/artwork.c src/motion_art.c src/enemy_art.c src/sound.c tests/host.c -o /tmp/rift_host_tests
ASAN_OPTIONS=detect_leaks=1 /tmp/rift_host_tests
python tests/convert_screens.py
