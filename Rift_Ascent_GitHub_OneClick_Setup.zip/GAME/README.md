# Rift Ascent: Warden's Ascent (PSP homebrew project)

**Status: full single-character game source and Windows one-click PSPDEV build pipeline; host-tested. Native PSP EBOOT linking, PPSSPP launch and hardware performance remain UNVERIFIED.**

Rift Ascent is an original dark-fantasy, turn-based, deck-building roguelike for a homebrew-enabled PlayStation Portable. The armored **Warden** climbs three acts of a ruined citadel. It draws inspiration from Slay the Spire's combat and progression loop without copying Slay the Spire's art or dialogue.

## Implemented content

- **Three 13-floor acts**, each with eight normal enemy types, three elite types and **one exclusive boss**: The Furnace Maw, The Crimson Judge and The Hollow King. **36 enemy species total**.
- **36 individually addressable 104×110 RGB565 enemy sprites**, using nine original painted character illustrations plus 27 artistically color-graded and embellished variants. All 36 are visually distinct, but they are not 36 separately hand-painted drawings.
- Each species has independent HP, attack strength and **four-move attack behavior** using 14 different intents (attacks, multiple hits, block, buffs, curses, poison, energy drain, healing, lifesteal and debuffs). Bosses enrage when bloodied.
- **50 playable cards** with upgrades, four unplayable status cards, 28 relics, six potions, draw/discard/exhaust, energy, defense, strength, weakness and vulnerability.
- Twelve random events with accept/decline choices, shops, treasure, rest sites, deck upgrades and removals, branching nodes, boss relics and three-act progression.
- Fully integrated 480×272 rendered screens, illustrated environments, hero and enemy idle movement, card hover motion, particles and attack/defense/potion effects, dynamically rendered health bars and enemy intentions.
- An original synthesized chiptune score, generated within the executable and streamed on a separate PSP audio thread.
- Automatic **SAVE.DAT** snapshots and a separate **PROFILE.DAT** for run counts, best floor, wins, losses and kills. Save data is checksummed. **GAME_VERSION 16** intentionally rejects saves from incompatible older pre-release builds; lifetime profiles retain their existing format.

## Controls

| PSP input | Function |
|---|---|
| D-pad | Select cards, map paths, choices and targets |
| Cross | Confirm/play selected card |
| Circle | End turn, go back |
| Square | Inspect deck |
| Triangle | Use potion in battle |
| Start | Help on map |

## Windows one-click compilation

From the outer archive, first install and start [Docker Desktop](https://docs.docker.com/desktop/setup/install/windows-install/), then double-click **BUILD_EBOOT.cmd**. The script fetches `pspdev/pspdev:v20261001` if necessary, builds in an isolated clean folder, validates the PBP format and embedded MIPS executable and places the output at `OUTPUT/EBOOT.PBP` **only on success**. If PPSSPPHeadless is present, the tool attempts a nonblank-frame screenshot smoke test. The GUI emulator may open for manual review, but this does not count as an automated pass.

With native PSPDEV tools already installed, run `./build_psp.sh`. GitHub Actions provides an alternative reproducible build workflow. The game executable embeds all required images; no separate runtime PNGs need to be copied to your PSP.

After a confirmed native build and boot, put the EBOOT at `PSP/GAME/RIFTASCENT/EBOOT.PBP`. The game saves to `ms0:/PSP/GAME/RIFTASCENT/`. A homebrew-compatible firmware configuration is required.

## Local verification

Run `bash verify.sh` on Linux with GCC, Clang, Python 3 and Pillow. The test script checks **all 36 encounter definitions**, correct act-exclusive bosses, all 14 enemy intent actions, 36 native sprite resources, 100 card variants, 201 seeded three-act progression tests, 500 random input sequences, 2,000 full controller-action AI runs, checksum saving/profile integrity, actual rendered screenshots, 36-frame animation tests, audio generation, a 14-frame mocked PSP main loop, and compilation of all seven modules to MIPS-II object files using Clang and PSP header stubs. See `QA_REPORT.md` for counts and limitations.

### Important release limitation

The authoring environment has **no official psp-gcc/PSPSDK linker, Docker, PPSSPP or physical PSP**, and outbound shell downloads are blocked. **No `EBOOT.PBP` has been successfully built or launched here.** PSP compatibility and frame rate therefore cannot be guaranteed. The Makefile and one-click pipeline use the official SDK, but this is *not* a certified handheld release. Earlier experimental EBOOTs were broken; they are **not** included.

## Source

- `src/game.c/.h` — all combat, enemies, events, map, saves and stats
- `src/render.c` — 480×272 software renderer with animation
- `src/artwork.c`, `src/motion_art.c`, `src/enemy_art.c` — embedded RGB565 art
- `src/sound.c` — original real-time chiptune
- `src/psp_main.c` — PSPSDK input, VRAM buffers, audio and save integration
- `tests/expand_enemy_art.py` — reproducible 27-variant enemy art synthesis from nine originals
- `tests/roster_test.c` — enemy availability, intent execution and exclusivity tests
- `screenshots/` — actual renderer previews, animation GIF and 36-character contact sheet

All the gameplay is original. Variant art is explicitly identified as derivative of the original game illustrations; no image is represented as unique hand-painted art when it is a recolored/augmented variant.
