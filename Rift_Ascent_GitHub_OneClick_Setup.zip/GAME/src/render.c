#include "game.h"
#include "font.h"
#include "artwork.h"
#include "motion_art.h"
#include "enemy_art.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define RGB(r,g,b) ((uint32_t)(0xff000000u|((uint32_t)(b)<<16)|((uint32_t)(g)<<8)|(r)))
#define MIN(a,b) ((a)<(b)?(a):(b))
#define CLAMP(x,a,b) ((x)<(a)?(a):((x)>(b)?(b):(x)))
#define BG RGB(12,18,29)
#define PANEL RGB(25,35,49)
#define GOLD RGB(235,186,111)
#define WHITE RGB(231,229,210)
#define MUTED RGB(137,156,163)
#define RED RGB(223,91,79)
#define GREEN RGB(109,203,151)
#define BLUE RGB(89,171,210)
#define PURPLE RGB(161,112,186)
static uint32_t*pix;static int sw;
static const RiftProfile *profile_data;
void game_render_set_profile(const RiftProfile*p){profile_data=p;}
static unsigned animation_tick;
static unsigned effect_start;
static int effect_kind;
/* Particle / idle animation uses integer math only. No timing clock, floats,
   textures or allocations are required inside the PSP frame loop. */
static int wave(unsigned tick,int period,int amplitude){
 unsigned phase=tick%(unsigned)period;
 unsigned half=(unsigned)period/2;
 return (int)((phase<half?phase:period-phase)*(unsigned)(amplitude*2)/half)-amplitude;
}
void game_effect_start(int kind,unsigned tick){effect_kind=kind;effect_start=tick;}

static void put(int x,int y,uint32_t c);
static void rect(int x,int y,int w,int h,uint32_t c);
static void border(int x,int y,int w,int h,uint32_t c);
/* RGB565 textures are stored in the EBOOT, so artwork has no memory-stick
   dependencies. Nearest-neighbor scaling is crisp on the PSP's 480x272 LCD. */
static void art_blit(int dx,int dy,int dw,int dh,const uint16_t *data,int iw,int ih){
 if(dw<=0||dh<=0)return;
 int x0=dx<0?0:dx,y0=dy<0?0:dy,x1=dx+dw>W?W:dx+dw,y1=dy+dh>H?H:dy+dh;
 for(int y=y0;y<y1;y++){
  const uint16_t *src=data+(size_t)(dh==ih?(y-dy):((y-dy)*ih/dh))*iw;
  uint32_t *dst=pix+(size_t)y*sw;
  for(int x=x0;x<x1;x++){
   uint16_t c=src[dw==iw?(x-dx):((x-dx)*iw/dw)];
   unsigned int r=(c>>11)&31,g=(c>>5)&63,b=c&31;
   r=(r<<3)|(r>>2);g=(g<<2)|(g>>4);b=(b<<3)|(b>>2);
   dst[x]=RGB(r,g,b);
  }
 }
}
/* PSP-compatible masked 16-bit sprite blitter (magenta colorkey). */
static void sprite(int dx,int dy,int w,int h,const uint16_t *data){
 int x0=dx<0?0:dx,y0=dy<0?0:dy,x1=dx+w>W?W:dx+w,y1=dy+h>H?H:dy+h;
 for(int y=y0;y<y1;y++){
  const uint16_t *src=data+(size_t)(y-dy)*w;
  uint32_t *dst=pix+(size_t)y*sw;
  for(int x=x0;x<x1;x++){
   uint16_t c=src[x-dx];if(c==RIFT_TRANSPARENT_565)continue;
   unsigned int r=(c>>11)&31,g=(c>>5)&63,b=c&31;
   dst[x]=RGB((r<<3)|(r>>2),(g<<2)|(g>>4),(b<<3)|(b>>2));
  }
 }
}
/* Scale 104x110 RGB565 creature frames with keyed transparency. */
static void sprite_scaled(int dx,int dy,int dw,int dh,const uint16_t *src,int iw,int ih){
 if(dw<1||dh<1)return;
 int x0=dx<0?0:dx,y0=dy<0?0:dy,x1=dx+dw>W?W:dx+dw,y1=dy+dh>H?H:dy+dh;
 for(int y=y0;y<y1;y++){
  const uint16_t *line=src+(size_t)((y-dy)*ih/dh)*iw;
  uint32_t *dst=pix+(size_t)y*sw;
  for(int x=x0;x<x1;x++){
   uint16_t c=line[(x-dx)*iw/dw];if(c==RIFT_TRANSPARENT_565)continue;
   unsigned int r=(c>>11)&31,g=(c>>5)&63,b=c&31;
   dst[x]=RGB((r<<3)|(r>>2),(g<<2)|(g>>4),(b<<3)|(b>>2));
  }
 }
}
static void dark_rect(int x,int y,int w,int h,int strength){
 if(x<0){w+=x;x=0;}if(y<0){h+=y;y=0;}
 if(x+w>W)w=W-x;
 if(y+h>H)h=H-y;
 if(w<=0||h<=0)return;
 for(int yy=y;yy<y+h;yy++)for(int xx=x;xx<x+w;xx++){
  uint32_t *c=pix+(size_t)yy*sw+xx;
  unsigned int r=(*c&255)*(256-strength)/256;
  unsigned int g=((*c>>8)&255)*(256-strength)/256;
  unsigned int b=((*c>>16)&255)*(256-strength)/256;
  *c=RGB(r,g,b);
 }
}
static void gilded_panel(int x,int y,int w,int h,int selected){
 rect(x+2,y+2,w,h,RGB(5,10,17));
 rect(x,y,w,h,RGB(15,25,38));
 border(x,y,w,h,selected?GOLD:RGB(121,97,69));
 rect(x+2,y+2,w-4,1,selected?GOLD:RGB(59,77,91));
 rect(x+2,y+h-3,w-4,1,RGB(44,54,64));
 put(x+2,y+2,GOLD);put(x+w-3,y+2,GOLD);
 put(x+2,y+h-3,GOLD);put(x+w-3,y+h-3,GOLD);
}
static void put(int x,int y,uint32_t c){if((unsigned)x<W&&(unsigned)y<H)pix[(size_t)y*sw+x]=c;}
static void rect(int x,int y,int w,int h,uint32_t c){if(x<0){w+=x;x=0;}if(y<0){h+=y;y=0;}if(x+w>W)w=W-x;if(y+h>H)h=H-y;if(w<1||h<1)return;for(int j=y;j<y+h;j++)for(int i=x;i<x+w;i++)pix[(size_t)j*sw+i]=c;}
static void line(int x0,int y0,int x1,int y1,uint32_t c){int dx=abs(x1-x0),sx=x0<x1?1:-1,dy=-abs(y1-y0),sy=y0<y1?1:-1,err=dx+dy;for(;;){put(x0,y0,c);if(x0==x1&&y0==y1)break;int e=2*err;if(e>=dy){err+=dy;x0+=sx;}if(e<=dx){err+=dx;y0+=sy;}}}
static void circle(int xc,int yc,int r,uint32_t c){for(int y=-r;y<=r;y++)for(int x=-r;x<=r;x++)if(x*x+y*y<=r*r)put(xc+x,yc+y,c);}
static void triangle(int x1,int y1,int x2,int y2,int x3,int y3,uint32_t c){int minx=x1<x2?(x1<x3?x1:x3):(x2<x3?x2:x3);int maxx=x1>x2?(x1>x3?x1:x3):(x2>x3?x2:x3);int miny=y1<y2?(y1<y3?y1:y3):(y2<y3?y2:y3);int maxy=y1>y2?(y1>y3?y1:y3):(y2>y3?y2:y3);minx=minx<0?0:minx;miny=miny<0?0:miny;maxx=maxx>=W?W-1:maxx;maxy=maxy>=H?H-1:maxy;int det=(y2-y3)*(x1-x3)+(x3-x2)*(y1-y3);if(det==0)return;for(int y=miny;y<=maxy;y++)for(int x=minx;x<=maxx;x++){int a=(y2-y3)*(x-x3)+(x3-x2)*(y-y3),b=(y3-y1)*(x-x3)+(x1-x3)*(y-y3),d=det-a-b;if(det>0?(a>=0&&b>=0&&d>=0):(a<=0&&b<=0&&d<=0))put(x,y,c);}}
static void border(int x,int y,int w,int h,uint32_t c){rect(x,y,w,1,c);rect(x,y+h-1,w,1,c);rect(x,y,1,h,c);rect(x+w-1,y,1,h,c);}
static void text(int x,int y,const char*s,uint32_t c,int size){if(!s)return;for(int n=0;s[n]&&x<W;n++){int chr=(unsigned char)s[n];if(chr<32||chr>126)chr='?';const unsigned char*glyph=rift_font[chr-32];for(int iy=0;iy<11;iy++)for(int ix=0;ix<7;ix++)if(glyph[iy]&(1<<ix))rect(x+ix*size,y+iy*size,size,size,c);x+=size*7;}}
static void center(int x,int y,const char*s,uint32_t c,int scale){int len=(int)strlen(s);text(x-len*7*scale/2,y,s,c,scale);}
static void fittext(int x,int y,const char*s,int n,uint32_t c){char b[128];snprintf(b,sizeof(b),"%.*s",n,s);text(x,y,b,c,1);}
static void button(int x,int y,int w,int h,const char*s,int selected){
 gilded_panel(x,y,w,h,selected);
 if(selected){rect(x+3,y+3,w-6,h-6,RGB(81,39,40));border(x+1,y+1,w-2,h-2,GOLD);}
 center(x+w/2,y+(h-11)/2,s,selected?RGB(253,216,156):WHITE,1);
}

static void wrapped_text(int x,int y,const char *source,int linechars,int maxlines,uint32_t c){
 int start=0,len=(int)strlen(source),row=0;
 while(start<len&&row<maxlines){
  while(start<len&&source[start]==' ')start++;
  if(start>=len)break;
  int stop=start+linechars;
  if(stop>=len)stop=len;
  else if(source[stop]!=' '){
   int end=stop;
   while(end>start&&source[end]!=' ')end--;
   if(end>start)stop=end;
  }
  char part[70];int n=stop-start;
  if(n>69)n=69;
  memcpy(part,source+start,(size_t)n);part[n]=0;
  text(x,y+row*11,part,c,1);
  start=stop;row++;
 }
}
static void bar(int x,int y,int w,int h,int current,int max,uint32_t c){rect(x,y,w,h,RGB(56,53,58));if(max>0)rect(x,y,(w*CLAMP(current,0,max))/max,h,c);border(x,y,w,h,RGB(176,151,124));}
/* self-contained integer clamp */
static void background(const Game*g){
 const uint16_t *src=ra_menu_bg;
 if(g->screen==TITLE)src=ra_title_bg;
 else if(g->screen==COMBAT)src=rift_combat_clean;
 else if(g->screen==MAP)src=ra_map_bg;
 else if(g->screen==REWARD||g->screen==BOSS_REWARD)src=ra_reward_bg;
 art_blit(0,0,W,H,src,W,H);
}
static unsigned particle_hash(unsigned x){
 x^=x>>16;x*=0x7feb352du;x^=x>>15;x*=0x846ca68bu;return x^(x>>16);
}
static void ambient_particles(const Game*g){
 if(g->screen!=COMBAT&&g->screen!=TITLE&&g->screen!=MAP&&g->screen!=REWARD)return;
 /* Looping ember motion and an irregular intermittent shimmer. */
 for(unsigned i=0;i<18;i++){
  unsigned seed=particle_hash(i*76543u+g->act*121u);
  unsigned travel=(animation_tick*(1u+(seed&3u))+(seed>>12))%181u;
  int x=(int)((seed%W)+((animation_tick/8u)%(15u)))-8;
  int y=177-(int)travel;
  unsigned flicker=particle_hash(seed+animation_tick/3u);
  uint32_t color=(flicker&7u)==0?RGB(251,182,106):RGB(176,63,50);
  if(y>45&&y<172&&x>=0&&x<W){
   rect(x,y,((seed>>8)&3u)==0?2:1,((seed>>5)&3u)==0?2:1,color);
  }
 }
}
static void header(const Game*g,const char*caption){
 rect(0,0,W,29,RGB(9,16,27));
 rect(0,27,W,1,RGB(149,106,63));
 text(11,7,"RIFT ASCENT",GOLD,1);
 char linebuf[128];snprintf(linebuf,sizeof(linebuf),"HP %d/%d",g->hp,g->maxhp);text(124,7,linebuf,RED,1);
 snprintf(linebuf,sizeof(linebuf),"$%d",g->gold);text(220,7,linebuf,GOLD,1);
 snprintf(linebuf,sizeof(linebuf),"ACT %d  FL %02d",g->act,g->floor+1);text(337,7,linebuf,WHITE,1);
 dark_rect(0,29,W,15,164);
 fittext(14,31,caption,63,MUTED);
}
static void footer(const char*help){
 rect(0,255,W,17,RGB(9,16,27));rect(0,255,W,1,RGB(115,85,60));
 text(8,258,help,MUTED,1);
}
static void enemy_art(int x,int y,const Enemy*e){
 int id=e->art;uint32_t cloak=id<3?RGB(63,87,86):id<6?RGB(115,59,65):RGB(100,92,91);
 circle(x,y+40,30,RGB(23,32,41));
 if(id==0){
  for(int k=-1;k<=1;k++)line(x+k*6,y+39,x+k*11,y+64,cloak);
  circle(x,y+12,19,cloak);circle(x,y+10,11,RGB(90,115,95));
  circle(x-6,y+5,3,RED);circle(x+6,y+5,3,RED);
  triangle(x-21,y+19,x-17,y-8,x-3,y+10,cloak);triangle(x+3,y+10,x+17,y-8,x+21,y+19,cloak);
 }else if(id==1||id==6){
  rect(x-19,y+15,38,43,cloak);triangle(x-22,y+20,x,y-17,x+22,y+20,RGB(127,126,113));
  rect(x-15,y+14,30,15,RGB(47,58,61));rect(x-10,y+16,6,3,RED);rect(x+4,y+16,6,3,RED);
  rect(x-24,y+33,13,20,RGB(104,108,103));rect(x+11,y+33,13,20,RGB(104,108,103));
  rect(x-15,y+58,12,9,RGB(112,111,97));rect(x+4,y+58,12,9,RGB(112,111,97));
 }else if(id==2||id==5){
  triangle(x-28,y+65,x,y-13,x+28,y+65,cloak);
  circle(x,y+3,18,RGB(25,30,37));circle(x,y+6,6,id==2?BLUE:RED);
  triangle(x-13,y+5,x,y-23,x+13,y+5,RGB(151,91,75));
  line(x+18,y+26,x+38,y-14,RGB(127,91,55));circle(x+39,y-15,8,id==2?BLUE:RED);
 }else{
  triangle(x-27,y+65,x,y+4,x+29,y+65,cloak);
  rect(x-20,y+8,40,42,RGB(85,79,85));
  circle(x,y+5,19,RGB(115,106,106));rect(x-14,y+6,28,10,RGB(32,41,46));
  rect(x-11,y+9,7,4,RED);rect(x+4,y+9,7,4,RED);
  triangle(x-14,y+5,x-19,y-25,x-2,y-4,RGB(123,121,119));
  triangle(x+2,y-4,x+19,y-25,x+14,y+5,RGB(123,121,119));
  if(id>=7){line(x+25,y+21,x+42,y-13,GOLD);triangle(x+35,y-15,x+52,y-30,x+47,y-5,GOLD);}
 }
}
static const char*intent_name(int n){static const char*s[]={"STRIKE","GUARD","WEAKEN","EXPOSE","EMPOWER","HEX","VENOM","DOUBLE","DRAIN","MEND","CRUSH","DREAD","LEECH","FORTIFY"};return n>=0&&n<14?s[n]:"???";}
static void card_render(int x,int y,int w,int h,int raw,int selected,int active){
 int id=CARD_ID(raw),up=CARD_UP(raw);const CardDef*d=&cards[id];
 uint32_t hue=d->type==0?RGB(138,51,50):d->type==1?RGB(47,91,133):d->type==2?RGB(105,62,130):RGB(85,81,75);
 const uint16_t *art=d->type==0?ra_art_strike:d->type==1?ra_art_block:d->type==2?ra_art_power:ra_art_curse;
 int tall=h>=110,arth=tall?57:21;
 gilded_panel(x,y,w,h,selected);
 rect(x+3,y+3,w-6,15,hue);
 char title[26];snprintf(title,sizeof(title),"%.12s%s",d->name,up?"+":"");
 fittext(x+20,y+5,title,(w-24)/7,WHITE);
 art_blit(x+4,y+19,w-8,arth,art,100,60);
 border(x+4,y+19,w-8,arth,RGB(100,80,67));
 char coststr[12];snprintf(coststr,sizeof(coststr),"%d",d->cost<0?0:d->cost);
 circle(x+9,y+10,9,RGB(29,98,150));circle(x+9,y+10,7,RGB(50,149,205));text(x+5,y+5,coststr,WHITE,1);
 wrapped_text(x+5,y+21+arth,card_description(raw),(w-10)/7,tall?4:2,selected?WHITE:MUTED);
 if(selected){border(x-1,y-1,w+2,h+2,GOLD);put(x-2,y-2,GOLD);put(x+w+1,y+h+1,GOLD);}
 if(!active)rect(x+3,y+h-4,w-6,2,RED);
}

static void combat(const Game*g){
 /* Independent animated hero and foe layers are extracted from the scene.
    Different enemy species use procedural sprites, not an incorrect wight. */
 int hero_bob=wave(animation_tick,110,2);
 sprite(RIFT_HERO_X,RIFT_HERO_Y+hero_bob,RIFT_HERO_W,RIFT_HERO_H,rift_hero);
 for(int i=0;i<g->enemy_count;i++){
  const Enemy *e=&g->enemies[i];if(e->hp<=0)continue;
  int ex=g->enemy_count==1?337:(i==0?333:425);
  int bob=wave(animation_tick+i*24u,96,2);
  if(e->art>=0&&e->art<ENEMY_COUNT){
   int dw=(g->enemy_count==1?106:82)+wave(animation_tick+i*9u,140,1);
   int dh=(g->enemy_count==1?111:96)+wave(animation_tick+i*13u,130,1);
   sprite_scaled(ex-dw/2,169-dh+bob,dw,dh,
     rift_enemy_sprites[e->art],RIFT_ENEMY_W,RIFT_ENEMY_H);
  }else enemy_art(ex,84+bob,e);
 }
 /* Short battle event animation is drawn behind live card/UI information. */
 if(effect_kind&&animation_tick>=effect_start&&animation_tick-effect_start<14){
  unsigned age=animation_tick-effect_start;
  if(effect_kind==1){ /* attack streak travelling to the target */
   int x=155+(int)age*12;
   for(int j=0;j<3;j++)line(x+j*5,78+j*9,x+j*5+19,55+j*9,(j==1?GOLD:RED));
  }else if(effect_kind==2){ /* defensive sigil around the hero */
   int r=22+(int)age;
   for(int k=0;k<22;k++){
    int px=100+((k*17)%r)-r/2;
    int py=115+((k*29)%r)-r/2;
    put(px,py,(k&1)?BLUE:WHITE);
   }
   border(78-(int)age/2,81-(int)age/2,48+(int)age,59+(int)age,BLUE);
  }else if(effect_kind==3){ /* healing/potion sparks */
   for(int k=0;k<14;k++){
    int px=95+(int)((particle_hash((unsigned)k*91u)%67u))-33;
    int py=156-(int)(age*3)-(k%3)*4;
    rect(px,py,2,3,GREEN);
   }
  }else if(effect_kind==4){ /* hit feedback */
   for(int k=0;k<7;k++)line(72+k*11,84+((int)age%4),62+k*11,96+((int)age%4),RED);
  }
 }
 header(g,"BATTLE / CROSS PLAY  CIRCLE END TURN");
 /* The illustrated reference contained placeholder HUD text. Occlude it
    so no static HP or intent labels compete with the live simulation. */
 dark_rect(283,29,129,46,237);
 rect(0,167,W,8,RGB(27,25,28));
 /* The battlefield and character illustrations are native embedded artwork;
    all stats and selections below are live gameplay data. */
 char b[100];
 dark_rect(37,143,122,25,107);
 snprintf(b,sizeof(b),"%d/%d HP",g->hp,g->maxhp);
 text(54,144,b,WHITE,1);
 bar(53,157,99,7,g->hp,g->maxhp,RED);
 if(g->block){snprintf(b,sizeof(b),"BLK %d",g->block);text(160,150,b,BLUE,1);}
 if(g->strength){snprintf(b,sizeof(b),"STR %d",g->strength);text(162,160,b,GOLD,1);}
 for(int i=0;i<g->enemy_count;i++){
  const Enemy*e=&g->enemies[i];if(e->hp<=0)continue;
  int ex=g->enemy_count==1?337:i==0?334:427;
  dark_rect(ex-48,34,96,32,184);
  if(strlen(e->name)>13){char label[14];memcpy(label,e->name,13);label[13]=0;center(ex,35,label,GOLD,1);}else center(ex,35,e->name,GOLD,1);
  snprintf(b,sizeof(b),"%s %d",intent_name(e->intent),e->intent_value);
  center(ex,50,b,e->intent==0||e->intent==2||e->intent==3?RED:GOLD,1);
  dark_rect(ex-42,142,84,28,144);
  snprintf(b,sizeof(b),"%d/%d",e->hp,e->maxhp);
  center(ex,142,b,WHITE,1);
  bar(ex-39,155,78,7,e->hp,e->maxhp,RED);
  if(e->block){snprintf(b,sizeof(b),"BLK %d",e->block);center(ex,163,b,BLUE,1);}
  if(i==g->target)border(ex-45,138,90,33,GOLD);
 }
 rect(0,175,W,80,RGB(10,17,29));rect(0,175,W,1,GOLD);
 circle(26,218,24,RGB(19,38,67));circle(26,218,19,(animation_tick/13u)&1u?RGB(43,140,198):RGB(36,122,180));circle(26,218,16,RGB(32,92,149));
 snprintf(b,sizeof(b),"%d",g->energy);center(26,207,b,WHITE,2);
 text(5,241,"ENERGY",MUTED,1);
 int visible=5,start=0;
 if(g->selection>=visible)start=g->selection-visible+1;
 for(int i=start;i<g->hand_count&&i<start+visible;i++){
  int x=56+(i-start)*73,selected=(i==g->selection),y=selected?180+wave(animation_tick,60,1):185;
  int id=CARD_ID(g->hand[i]);
  card_render(x,y,70,selected?72:67,g->hand[i],selected,cards[id].cost!=-2&&(cards[id].cost<=g->energy||cards[id].cost==-1));
 }
 button(426,198,48,40,"END",0);
 if(g->potion_count>0){snprintf(b,sizeof(b),"POT %d",g->potion_count);text(426,241,b,GREEN,1);}
 footer("D-PAD CARD/TARGET    X PLAY    O END    TRIANGLE POTION");
}
static uint32_t node_color(int n){switch(n){case NODE_FIGHT:return RED;case NODE_ELITE:return PURPLE;case NODE_EVENT:return BLUE;case NODE_REST:return GREEN;case NODE_SHOP:return GOLD;case NODE_TREASURE:return RGB(209,160,72);default:return WHITE;}}
static char node_symbol(int n){return "FE?SR$B"[CLAMP(n,0,6)];}
static void map_screen(const Game*g){
 header(g,"FATE'S PATH / CHOOSE A CONNECTED NODE");
 border(17,45,300,202,RGB(175,132,73));gilded_panel(319,47,156,200,0);
 int first=CLAMP(g->floor-2,0,MAP_ROWS-5);
 if(g->floor==MAP_ROWS)first=MAP_ROWS-5;
 for(int r=first;r<first+5&&r<MAP_ROWS;r++){
  int y=220-(r-first)*37;
  for(int c=0;c<3;c++){
   int x=79+c*89;
   if(r<MAP_ROWS-1){for(int d=0;d<3;d++)if(abs(d-c)<=1)line(x,y-12,79+d*89,y-25,RGB(101,77,53));}
  }
 }
 for(int r=first;r<first+5&&r<MAP_ROWS;r++){
  int y=220-(r-first)*37;
  for(int c=0;c<3;c++){
   int x=79+c*89,n=g->map[r][c],done=r<g->floor,available=r==g->floor&&(r==0||abs(c-g->lane)<=1);
   uint32_t col=node_color(n);
   circle(x,y,13,done?RGB(45,50,57):available?RGB(180,125,61):RGB(35,47,62));
   circle(x,y,9,done?RGB(73,76,77):col);
   char s[]={node_symbol(n),0};center(x,y-5,s,BG,1);
   if(r==g->floor&&c==g->selection){
    border(x-15,y-15,30,30,((animation_tick/16u)&1u)?GOLD:RGB(252,226,168));
    if((animation_tick%42u)<22u)put(x+17,y-19,GOLD);
   }
   if(done&&g->map_selected[r]==c)circle(x,y+12,3,GREEN);
   char num[16];snprintf(num,sizeof(num),"%02d",r+1);text(26,y-5,num,MUTED,1);
  }
 }
 text(324,63,"THE ASCENT",GOLD,1);
 char b[60];snprintf(b,sizeof(b),"ACT %d / 3",g->act);text(325,85,b,WHITE,1);
 snprintf(b,sizeof(b),"FLOOR %d/13",g->floor+1);text(325,103,b,WHITE,1);
 text(325,130,"NEXT",MUTED,1);
 if(g->floor<MAP_ROWS)text(325,147,node_name(g->map[g->floor][g->selection]),node_color(g->map[g->floor][g->selection]),1);
 else text(325,147,"THE BOSS",RED,1);
 text(324,177,"X  ENTER",GOLD,1);text(324,196,"SQUARE DECK",MUTED,1);
 footer("LEFT/RIGHT SELECT   X ENTER    SQUARE VIEW DECK");
}
static void reward_screen(const Game*g){
 header(g,"VICTORY / CHOOSE A CARD TO ADD");
 rect(38,44,403,38,RGB(12,21,35));
 center(240,54,"SPOILS OF BATTLE",GOLD,2);
 for(int i=0;i<3;i++)card_render(57+i*132,90,102,134,g->reward[i],g->selection==i,1);
 button(198,227,84,22,"SKIP",g->selection==3);
 footer("LEFT/RIGHT SELECT     X TAKE CARD OR SKIP");
}
static void boss_reward_screen(const Game*g){
 header(g,"GUARDIAN DEFEATED / SELECT A RELIC");
 center(240,58,"CHOOSE YOUR SPOILS",GOLD,2);
 for(int i=0;i<3;i++){
  int x=30+i*148,y=102,selected=g->selection==i;
  rect(x,y,131,119,RGB(30,38,50));border(x,y,131,119,selected?GOLD:RGB(75,83,92));
  circle(x+65,y+36,27,RGB(65,49,67));
  triangle(x+65,y+13,x+42,y+44,x+65,y+68,PURPLE);
  triangle(x+65,y+13,x+88,y+44,x+65,y+68,GOLD);
  if(g->reward[i]>=0){
   center(x+65,y+79,relic_defs[g->reward[i]].name,GOLD,1);
   fittext(x+5,y+100,relic_defs[g->reward[i]].desc,17,WHITE);
  }
 }
 footer("LEFT/RIGHT SELECT   X ACCEPT RELIC AND ASCEND");
}
static void rest_screen(const Game*g){
 header(g,"REST SITE / A MOMENT OF PEACE");
 circle(230,122,37,RGB(71,49,39));triangle(199,155,232,63,264,155,RGB(197,91,51));
 triangle(215,154,235,90,253,154,GOLD);
 circle(229,138,12,RGB(251,187,85));
 center(240,54,"THE EMBERS REMAIN",GOLD,1);
 button(49,189,179,38,"REST - HEAL 30%",g->selection==0);
 button(254,189,175,38,"FORGE - UPGRADE",g->selection==1);
 footer("LEFT/RIGHT SELECT    X CONFIRM");
}
static const char*event_titles[]={"CURSED PURSE","MOON SPRING","FORGOTTEN TOME","ANCIENT SHRINE","TRAPPED CHEST","LOST TRAVELER","FORGOTTEN ARMORY","LIVING ALTAR","BLACK WATER","CINDER GAMBIT","RUSTED FORGE","LAST SENTINEL"};
static const char*event_choices[]={"75 GOLD / LOSE 8 HP","HEAL 20 / PAY 40 GOLD","GET UPGRADED CARD","GAIN 5 MAX HP","RELIC / LOSE 7 HP","HEAL 8 / GAIN 30 GOLD","GET 2 CARDS / LOSE 10 HP","GAIN 10 MAX HP / LOSE 17 HP","HEAL 28 / ADD INJURY","110 GOLD / LOSE 16 HP","UPGRADE 2 / PAY 12 GOLD","GET RELIC / ADD DREAD"};
static void event_screen(const Game*g){
 header(g,"UNKNOWN / A CHOICE IN THE DARK");
 center(240,62,event_titles[g->effect_turn],GOLD,2);
 circle(240,133,34,RGB(46,46,62));
 for(int i=0;i<8;i++){int x=240+(i-4)*11;line(x,125,x+5,145,PURPLE);}circle(238,117,12,GOLD);
 center(240,171,event_choices[g->effect_turn],WHITE,1);
 button(60,206,170,30,"ACCEPT",g->selection==0);button(251,206,170,30,"LEAVE",g->selection==1);
 footer("LEFT/RIGHT CHOOSE    X CONFIRM");
}
static void shop_screen(const Game*g){
 header(g,"BLACK MARKET / SPEND YOUR COINS");
 text(26,55,"WARES",GOLD,1);
 int discount=0;for(int i=0;i<g->relic_count;i++)if(g->relics[i]==6)discount=15;
 for(int i=0;i<8;i++){
  int y=70+i*22,sel=g->selection==i;
  rect(20,y,441,20,sel?RGB(79,64,47):RGB(28,37,48));
  border(20,y,441,20,sel?GOLD:RGB(50,64,72));
  char linebuf[128];
  if(i<3){int id=g->shop_cards[i];if(id<0)snprintf(linebuf,sizeof(linebuf),"SOLD OUT");else snprintf(linebuf,sizeof(linebuf),"%s     %d G",cards[id].name,50+25*cards[id].rarity-discount);}
  else if(i==3)snprintf(linebuf,sizeof(linebuf),"%s      155 G",g->shop_relic>=0?relic_defs[g->shop_relic].name:"SOLD OUT");
  else if(i==4)snprintf(linebuf,sizeof(linebuf),"HEAL 18 HP     45 G");
  else if(i==5)snprintf(linebuf,sizeof(linebuf),"REMOVE ONE CARD     60 G");
  else if(i==6)snprintf(linebuf,sizeof(linebuf),"LEAVE SHOP");
  else snprintf(linebuf,sizeof(linebuf),"RANDOM POTION       50 G");
  fittext(35,y+4,linebuf,53,sel?GOLD:WHITE);
 }
 footer("UP/DOWN SELECT    X BUY    O LEAVE");
}
static void deck_screen(const Game*g){
 header(g,"THE GRIMOIRE / YOUR DECK");
 char b[80];snprintf(b,sizeof(b),"%d CARDS",g->deck_count);text(375,49,b,GOLD,1);
 int st=CLAMP(g->selection-5,0,(g->deck_count>11?g->deck_count-11:0));
 for(int i=st;i<g->deck_count&&i<st+11;i++){
  int y=60+(i-st)*17,id=CARD_ID(g->deck[i]);
  if(i==g->selection)rect(15,y,451,17,RGB(74,63,50));
  snprintf(b,sizeof(b),"%2d.  %s%s",i+1,cards[id].name,CARD_UP(g->deck[i])?"+":"");
  fittext(23,y+2,b,38,i==g->selection?GOLD:WHITE);
  fittext(235,y+2,card_description(g->deck[i]),33,MUTED);
 }
 footer(g->prior_screen==REST?"UP/DOWN SELECT   X UPGRADE CARD   O RETURN":g->prior_screen==SHOP?"UP/DOWN SELECT   X REMOVE CARD   O RETURN":"UP/DOWN SCROLL     O RETURN");
}
static void title_screen(const Game*g){
 (void)g;
 /* High-resolution original title art is converted to a 480x272 RGB565
    texture; the real executable menu is intentionally separate. */
 rect(176,131,135,19,RGB(11,19,31));
 button(177,151,134,30,"X - NEW RUN",1);
 button(177,187,134,27,"SQUARE - HELP",0);
 if(profile_data&&profile_data->runs){
  char b[74];snprintf(b,sizeof(b),"RUNS %lu   WINS %lu   BEST FL %lu",
   (unsigned long)profile_data->runs,(unsigned long)profile_data->wins,
   (unsigned long)profile_data->furthest_floor);
  center(244,230,b,GOLD,1);
 }else center(244,230,"ONE WARRIOR / THREE ACTS",GOLD,1);
 footer("X BEGIN ASCENT     SQUARE CONTROLS");
}
static void help_screen(const Game*g){
 header(g,"WALK THE SPIRE / CONTROLS");
 text(29,67,"D-PAD  Navigate cards, paths and menus",WHITE,1);
 text(29,87,"CROSS  Select or play a card",WHITE,1);
 text(29,107,"CIRCLE End turn / cancel",WHITE,1);
 text(29,127,"SQUARE View your deck",WHITE,1);
 text(29,147,"TRIANGLE Use next potion in battle",WHITE,1);
 text(29,167,"Win fights, grow your deck, defeat 3 bosses.",GOLD,1);
 text(29,187,"Gold buys cards, relics and rest. Heal wisely.",MUTED,1);
 text(29,215,"CROSS / CIRCLE   RETURN",GOLD,1);
 footer("RIFT ASCENT  /  ONE WARRIOR  /  THREE ACTS");
}
static void end_screen(const Game*g){
 header(g,g->screen==VICTORY?"VICTORY / THE HOLLOW KING FALLS":"DEFEAT / THE DARKNESS CLAIMS YOU");
 center(240,77,g->screen==VICTORY?"ASCENT COMPLETE":"THE END",g->screen==VICTORY?GOLD:RED,2);
 char b[80];snprintf(b,sizeof(b),"FOES VANQUISHED: %d",g->kill_count);center(240,130,b,WHITE,1);
 snprintf(b,sizeof(b),"FINAL DECK: %d CARDS",g->deck_count);center(240,150,b,WHITE,1);
 button(139,190,202,35,"X - NEW RUN",1);
 footer("EVERY RUN IS A NEW STORY");
}
void game_render_frame(const Game*g,uint32_t*pixels,int stride,unsigned tick){
 animation_tick=tick;
 pix=pixels;sw=stride;background(g);
 ambient_particles(g);
 switch(g->screen){
 case TITLE:title_screen(g);break;
 case MAP:map_screen(g);break;
 case COMBAT:combat(g);break;
 case REWARD:reward_screen(g);break;
 case BOSS_REWARD:boss_reward_screen(g);break;
 case REST:rest_screen(g);break;
 case SHOP:shop_screen(g);break;
 case EVENT:event_screen(g);break;
 case DECK_VIEW:deck_screen(g);break;
 case VICTORY:case DEFEAT:end_screen(g);break;
 case HELP:help_screen(g);break;
 }
}

/* Existing callers get a deterministic still frame. PSP uses animated frames. */
void game_render(const Game*g,uint32_t*pixels,int stride){
 game_render_frame(g,pixels,stride,0);
}
