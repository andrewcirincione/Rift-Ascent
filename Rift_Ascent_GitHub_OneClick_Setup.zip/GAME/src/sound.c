/* Original three-voice chiptune: arpeggiated bell, low triangular drone,
   and dry clockwork percussion. No samples or copyrighted audio. */
#include "sound.h"
#include <stdint.h>
static const unsigned short melody[16]={262,0,311,0,392,349,311,0,262,0,233,0,196,233,262,0};
static const unsigned short battle_line[16]={175,175,0,233,175,0,311,0,175,175,233,262,311,0,349,233};
static const unsigned short bassline[8]={65,65,78,78,58,58,52,58};
static int16_t clamp16(int v){return (int16_t)(v>32000?32000:(v< -32000?-32000:v));}
void rift_audio_generate(RiftSound*s,int16_t*out,int frames,int battle,int accent){
 if(!s||!out||frames<0)return;
 for(int i=0;i<frames;i++){
  unsigned int step=(s->pos/(battle?6200u:11200u))&15u;
  unsigned int in_step=(s->pos%(battle?6200u:11200u));
  unsigned int hz=(battle?battle_line:melody)[step];
  s->lead+=(hz*65536u)/44100u;
  s->bass+=(bassline[(step/2)&7]*65536u)/44100u;
  s->noise^=s->noise<<13;s->noise^=s->noise>>17;s->noise^=s->noise<<5;
  if(!s->noise)s->noise=0x7168ffabu;
  int lead=hz?((s->lead&32768u)?1:-1)*(in_step<2400?500:270):0;
  int v=(int)(s->bass&65535u);
  int tri=(v<32768?v:65535-v)-16384;
  int bass=(tri*1100)/16384;
  int beat=((in_step<500)&&(step%4==0))?((s->noise&1)?1400:-1400):0;
  int hihat=(in_step<280&&step%2==0)?((s->noise&1)?250:-250):0;
  int sfx=(accent&&in_step<900)?((s->noise&1)?480:-480):0;
  int l=lead+bass+beat+hihat+sfx;
  int r=lead+bass-beat+hihat+sfx;
  out[i*2]=clamp16(l);out[i*2+1]=clamp16(r);
  s->pos++;
 }
}
