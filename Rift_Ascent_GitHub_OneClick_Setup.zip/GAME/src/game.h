#ifndef RIFT_ASCENT_GAME_H
#define RIFT_ASCENT_GAME_H
#include <stdint.h>
#include <stddef.h>
#define W 480
#define H 272
#define MAX_DECK 128
#define MAX_HAND 10
#define MAX_PILE 128
#define MAX_ENEMIES 2
#define ENEMY_COUNT 36
#define MAX_RELICS 40
#define MAX_POTIONS 3
#define MAP_ROWS 12
#define MAP_LANES 3
#define GAME_VERSION 16

enum {TITLE,MAP,COMBAT,REWARD,REST,SHOP,EVENT,DECK_VIEW,VICTORY,DEFEAT,HELP,BOSS_REWARD};
enum {NODE_FIGHT,NODE_ELITE,NODE_EVENT,NODE_SHOP,NODE_REST,NODE_TREASURE,NODE_BOSS};
enum {BTN_UP=1,BTN_DOWN=2,BTN_LEFT=4,BTN_RIGHT=8,BTN_OK=16,BTN_BACK=32,BTN_ALT=64,BTN_POTION=128,BTN_START=256};
#define UPBIT 0x80
#define CARD_ID(x) ((x)&0x7f)
#define CARD_UP(x) (((x)&UPBIT)!=0)

typedef struct {char name[24];short hp,maxhp,block,strength,weak,vulnerable,poison;short intent,intent_value,phase;short art;} Enemy;
typedef struct {
 uint32_t magic,version,seed,rng;
 int screen,prior_screen,act,floor,lane,selection,target,scroll;
 int hp,maxhp,block,energy,max_energy,gold,turn,energy_penalty,strength,dexterity,weak,vulnerable,poison;
 int potion_count,potions[MAX_POTIONS],relic_count,relics[MAX_RELICS];
 int deck_count,deck[MAX_DECK],master_index;
 int draw_count,draw[MAX_PILE],discard_count,discard[MAX_PILE],exhaust_count,exhaust[MAX_PILE],hand_count,hand[MAX_HAND];
 int map[MAP_ROWS][MAP_LANES],map_selected[MAP_ROWS],enemy_count,reward[3],reward_gold;
 Enemy enemies[MAX_ENEMIES];
 int next_screen,battle_type,kill_count,defense_event,shop_cards[3],shop_relic;
 int reward_potion,win_screen,effect_turn,turn_played,used_potion,heal_after_battle;
 int permanent_strength,low_hp_triggered;
 char message[72], subtitle[72];
} Game;

/* Persistent lifetime achievements are stored separately from the run slot. */
typedef struct {
 uint32_t magic, version, runs, wins, losses;
 uint32_t furthest_floor, total_kills, best_kills, best_deck;
 uint32_t last_seed, last_result;
} RiftProfile;
void profile_init(RiftProfile *profile);
int profile_record(RiftProfile *profile,const Game *finished_run);
int profile_save(const RiftProfile *profile,const char *path);
int profile_load(RiftProfile *profile,const char *path);
void game_render_set_profile(const RiftProfile *profile);
typedef struct {const char *name;const char *desc;int cost,rarity,type;} CardDef;
typedef struct {const char *name;const char *desc;} RelicDef;
extern const CardDef cards[];
extern const int CARD_COUNT;
extern const RelicDef relic_defs[];
extern const int RELIC_COUNT;
const char *node_name(int type);
const char *game_enemy_name(int id);
const char *card_description(int raw);
void game_new(Game *g,uint32_t seed);
void game_action(Game *g,int button);
void game_update(Game *g);
void game_render(const Game *g,uint32_t *pixels,int stride);
void game_render_frame(const Game *g,uint32_t *pixels,int stride,unsigned tick);
/* Cosmetic battle effects: attack=1, defend=2, potion=3, hit=4. */
void game_effect_start(int kind,unsigned tick);
int game_save(const Game *g,const char *path);
int game_load(Game *g,const char *path);
int game_validate(const Game *g);
void game_start_battle(Game *g,int mode);
void game_start_turn(Game *g);
void game_end_turn(Game *g);
void game_play_card(Game *g,int index,int enemy);
void game_choose_node(Game *g,int lane);
uint32_t game_random(Game *g);
#endif
