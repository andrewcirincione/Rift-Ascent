#include "game.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

/* Completely original names, text, effects, and art. */
const CardDef cards[]={
 {"Cut","Deal 6 damage",1,0,0},                         //0
 {"Brace","Gain 5 block",1,0,1},                       //1
 {"Sunder","8 damage; 2 vulnerable",2,0,0},            //2
 {"Cleaving Arc","Deal 8 to all foes",1,1,0},          //3
 {"Wound Up","Draw 2 cards",1,1,2},                    //4
 {"Thick Hide","Gain 9 block",2,1,1},                  //5
 {"Blood Toll","Lose 3 HP; gain 2 energy",0,1,2},     //6
 {"Hammerfall","Deal 15 damage",2,1,0},               //7
 {"War Chant","Gain 2 strength",2,2,2},                //8
 {"Bastion","Gain 15 block",2,2,1},                    //9
 {"Cyclone","Deal 4 to all, X times",-1,2,0},         //10
 {"Rupture","Deal 7; draw 1",1,1,0},                   //11
 {"Shield Crash","Block 7 and hit 7",2,1,0},          //12
 {"Siphon","Heal 3; deal 5",1,1,0},                    //13
 {"Rust Cut","Deal 4; inflict 2 weak",1,1,0},         //14
 {"Overpower","Deal 22; suffer 2 weak",3,2,0},        //15
 {"Preparation","Gain 1 energy; draw 1",0,1,2},      //16
 {"Stand Fast","Gain 4 block; draw 1",1,1,1},          //17
 {"Counterweight","Gain 3 strength; lose 5 HP",1,2,2},//18
 {"Crack Armor","Deal 9; inflict 3 vulnerable",2,1,0},//19
 {"Blood Pact","Heal 8; exhaust",1,2,2},              //20
 {"Ground Slam","Deal damage equal to block",1,2,0},  //21
 {"Blade Storm","Deal 3 four times",2,2,0},           //22
 {"Fortify","Gain 12 block; gain 1 dex",2,2,1},      //23
 {"Last Stand","Gain 22 block; exhaust",2,2,1},       //24
 {"Vital Strike","Deal 7; heal 2",1,1,0},             //25
 {"War Cry","Draw 3; discard 1",0,1,2},               //26
 {"Swift Blade","Deal 5 twice",1,1,0},                //27
 {"Juggernaut","Strength +1; block 8",2,2,2},         //28
 {"Reckless","Deal 17; lose 4 HP",1,2,0},              //29
 {"Twin Guard","Gain 4 block twice",1,1,1},           //30
 {"Taunt","Inflict 3 weak; gain 3 block",1,1,2},      //31
 {"Shatter","Deal 13; remove enemy block",2,1,0},     //32
 {"Quick Guard","Gain 5 block; draw 1",1,1,1},        //33
 {"Battle Hymn","Gain 1 strength and 1 energy",1,2,2},//34
 {"Piercing Strike","Deal 9; ignore block",2,1,0},  //35
 {"Iron Tempest","All enemies: 12 damage",2,2,0},     //36
 {"Coagulate","Heal 5 and gain 5 block",2,2,1},       //37
 {"Redline","Draw 3; lose 2 HP",0,2,2},               //38
 {"Bone Crusher","Deal 12; weak 2",2,2,0},           //39
 {"Grit","Block 7; add 1 strength",2,1,1},             //40
 {"Riposte","Block 6; deal 6",1,1,0},                 //41
 {"Decimate","Deal 28; exhaust",3,2,0},               //42
 {"Sacrifice","Lose 5 HP; draw 4",0,2,2},             //43
 {"Firebrand","Deal 5; strength +1",1,2,0},           //44
 {"Adrenal Force","Energy +2; exhaust",0,2,2},        //45
 {"Dark Shield","Block 20; lose 3 HP",1,2,1},         //46
 {"Mercy Blade","Deal 11; heal if kill",2,1,0},       //47
 {"Battle Focus","Strength +2; exhaust",1,2,2},       //48
 {"Fracture","Deal 6; vulnerable 2; draw 1",1,2,0},   //49
 {"Burn","Unplayable; hurts at end",-2,0,3},          //50
 {"Daze","Unplayable",-2,0,3},                         //51
 {"Injury","Unplayable",-2,0,3},                       //52
 {"Dread","Unplayable; lose energy",-2,0,3}           //53
};
const int CARD_COUNT=(int)(sizeof(cards)/sizeof(cards[0]));
static const char *upgrade_descriptions[50]={
 "Deal 9 damage","Gain 8 block","11 damage; 3 vulnerable","Deal 11 to all foes",
 "Draw 3 cards","Gain 12 block","Lose 2 HP; gain 3 energy","Deal 21 damage",
 "Gain 3 strength","Gain 21 block","Deal 6 to all, X times","Deal 10; draw 1",
 "Block 10 and hit 10","Heal 5; deal 8","Deal 7; inflict 3 weak","Deal 28; suffer 1 weak",
 "Gain 2 energy; draw 1","Gain 7 block; draw 1","Gain 4 strength; lose 5 HP","Deal 12; inflict 4 vulnerable",
 "Heal 14; exhaust","Deal block + 5 as damage","Deal 3 five times","Gain 15 block; gain 2 dex",
 "Gain 28 block; exhaust","Deal 10; heal 3","Draw 4; discard 1","Deal 8 twice",
 "Strength +2; block 11","Deal 23; lose 4 HP","Gain 7 block twice","Inflict 4 weak; gain 6 block",
 "Deal 16; remove enemy block","Gain 8 block; draw 1","Gain 2 strength and 1 energy","Deal 12; ignore block",
 "All enemies: 18 damage","Heal 7 and gain 8 block","Draw 4; lose 2 HP","Deal 15; weak 3",
 "Block 10; add 1 strength","Block 9; deal 9","Deal 37; exhaust","Lose 5 HP; draw 5",
 "Deal 8; strength +1","Energy +3; exhaust","Block 26; lose 3 HP","Deal 14; heal 8 if kill",
 "Strength +3; exhaust","Deal 9; vulnerable 3; draw 1"
};
const char *card_description(int raw){
 int id=CARD_ID(raw);
 if(id<0||id>=CARD_COUNT)return "Unknown card";
 if(CARD_UP(raw)&&id<50)return upgrade_descriptions[id];
 return cards[id].desc;
}

const RelicDef relic_defs[]={
 {"Cinder Heart","Heal 6 after combat"},{"Copper Ring","First turn gains 1 energy"},
 {"Spiked Mail","Deal 3 damage when hit"},{"Glass Emblem","First attack +5 damage"},
 {"Stone Flask","Increase max HP by 10"},{"Fury Censer","Start combat with +1 strength"},
 {"Merchant Coin","Shop prices reduced"},{"Old Compass","Gain 1 draw on turn one"},
 {"Resting Idol","Recover 5 more HP at rests"},{"Rust Amulet","First attack applies weak"},
 {"Guardian Knot","Start combat with 8 block"},{"Ashen Crown","Gain 1 energy, lose 12 max HP"},
 {"Medal of Valor","Gain 1 strength after elite battles"},{"Locket","Card rewards are upgraded"},
 {"Burning Thorn","Gain 1 strength at half HP"},{"Fortress Pin","Block cards +2"},
 {"Gold Tooth","Gain 12 extra gold from fights"},{"Violet Orb","Potion effects stronger"},
 {"Sage's Ink","Draw 1 additional card each turn"},{"Broken Clock","All foes begin with vulnerable"},
 {"Iron Seed","Heal 2 every three turns"},{"Wildflower","Gain 2 block when using potion"},
 {"Worn Chain","Start combat with +1 dexterity"},{"Last Ember","Survive lethal hit once per act"},
 {"Bloodstone","Heal 1 after each attack"},{"Sun Token","Gain +1 max energy, lose 1 draw"},
 {"Hollow Skull","Deals +2 damage at 1 HP"},{"Scavenger","Gain +5 gold per reward"}
};
const int RELIC_COUNT=(int)(sizeof(relic_defs)/sizeof(relic_defs[0]));
#define MIN(a,b) ((a)<(b)?(a):(b))
#define MAX(a,b) ((a)>(b)?(a):(b))
#define CLAMP(x,a,b) MAX(a,MIN(x,b))

uint32_t game_random(Game *g){uint32_t x=g->rng;x^=x<<13;x^=x>>17;x^=x<<5;g->rng=x?x:0x4563871bu;return g->rng;}
static int rnd(Game *g,int max){return max>0?(int)(game_random(g)%(uint32_t)max):0;}
static int relic(const Game *g,int id){for(int i=0;i<g->relic_count;i++)if(g->relics[i]==id)return 1;return 0;}
static void enter_map(Game *g){g->screen=MAP;g->selection=CLAMP(g->lane,0,2);}
static void msg(Game*g,const char *s){snprintf(g->message,sizeof(g->message),"%s",s);}
static void add_card(Game*g,int c){if(g->deck_count<MAX_DECK)g->deck[g->deck_count++]=c;}
static int card_reward(Game*g){int r=rnd(g,100);int rarity=r<13?2:(r<60?1:0);int tries=0;for(;;){int id=rnd(g,CARD_COUNT-4);if(cards[id].rarity==rarity||tries++>100)return id;}}
static void fill_rewards(Game*g){for(int i=0;i<3;i++){int c;do{c=card_reward(g);}while((i>0&&c==CARD_ID(g->reward[0]))||(i>1&&c==CARD_ID(g->reward[1])));g->reward[i]=c|(relic(g,13)?UPBIT:0);}}
static void add_relic(Game*g,int id){if(g->relic_count>=MAX_RELICS||relic(g,id))return;g->relics[g->relic_count++]=id;if(id==4){g->maxhp+=10;g->hp+=10;}if(id==11){g->max_energy++;g->maxhp=MAX(1,g->maxhp-12);g->hp=MIN(g->hp,g->maxhp);}if(id==25)g->max_energy++;}
static int random_relic(Game*g){int id;for(int i=0;i<100;i++){id=1+rnd(g,RELIC_COUNT-1);if(!relic(g,id))return id;}return -1;}
static void map_generate(Game*g){
 for(int r=0;r<MAP_ROWS;r++)for(int c=0;c<MAP_LANES;c++){
  int pick=rnd(g,100),n;
  if(r==0)n=NODE_FIGHT;
  else if(r==MAP_ROWS-1)n=NODE_REST;
  else if(r==5)n=(c==1?NODE_SHOP:NODE_EVENT);
  else if(r==8)n=(c==1?NODE_ELITE:NODE_TREASURE);
  else if(r==3)n=pick<40?NODE_EVENT:(pick<85?NODE_FIGHT:NODE_ELITE);
  else n=pick<55?NODE_FIGHT:(pick<70?NODE_EVENT:(pick<82?NODE_ELITE:(pick<93?NODE_SHOP:NODE_REST)));
  g->map[r][c]=n;
 }
 for(int r=0;r<MAP_ROWS;r++)g->map_selected[r]=-1;
}
static void shuffle(Game*g,int *p,int count){for(int i=count-1;i>0;i--){int j=rnd(g,i+1),temp=p[i];p[i]=p[j];p[j]=temp;}}
static void draw_card(Game*g){
 if(g->hand_count>=MAX_HAND)return;
 if(!g->draw_count){if(!g->discard_count)return;memcpy(g->draw,g->discard,(size_t)g->discard_count*sizeof(int));g->draw_count=g->discard_count;g->discard_count=0;shuffle(g,g->draw,g->draw_count);}
 g->hand[g->hand_count++]=g->draw[--g->draw_count];
}
static void reshuffle_battle(Game*g){g->draw_count=g->deck_count;memcpy(g->draw,g->deck,(size_t)g->deck_count*sizeof(int));shuffle(g,g->draw,g->draw_count);g->discard_count=g->exhaust_count=g->hand_count=0;}
static void heal(Game*g,int n){g->hp=MIN(g->maxhp,g->hp+MAX(n,0));}
static void player_death(Game*g){
 if(g->hp>0)return;
 if(relic(g,23)&&g->defense_event!=g->act){g->defense_event=g->act;g->hp=1;msg(g,"Last Ember saved your life!");}
 else{g->hp=0;g->screen=DEFEAT;}
}
static void lose_hp(Game*g,int n){g->hp-=MAX(n,0);player_death(g);}
static void damage_player(Game*g,int n){
 if(n<=0)return;
 if(g->vulnerable) n=n*3/2;
 int blocked=MIN(g->block,n);g->block-=blocked;n-=blocked;
 if(n>0){g->hp-=n;if(relic(g,2)){for(int i=0;i<g->enemy_count;i++)g->enemies[i].hp-=3;}}
 player_death(g);
}
static void damage_enemy(Game*g,int idx,int amt,int ignore_block){
 if(idx<0||idx>=g->enemy_count||g->enemies[idx].hp<=0)return;
 Enemy *e=&g->enemies[idx];
 amt=MAX(0,amt+g->strength);
 if(g->weak)amt=amt*3/4;
 if(e->vulnerable)amt=amt*3/2;
 if(relic(g,3)&&g->turn_played==0)amt+=5;
 if(relic(g,26)&&g->hp==1)amt+=2;
 if(!ignore_block){int b=MIN(e->block,amt);e->block-=b;amt-=b;}
 e->hp-=amt;
 if(relic(g,9)&&g->turn_played==0)e->weak=MAX(e->weak,1);
 if(relic(g,24))heal(g,1);
}
static void deal(Game*g,int idx,int n){damage_enemy(g,idx,n,0);}
static void gain_block(Game*g,int n){g->block+=MAX(0,n+g->dexterity+(relic(g,15)?2:0));g->block=MIN(g->block,999);}
static void check_win(Game*g){
 for(int i=0;i<g->enemy_count;i++)if(g->enemies[i].hp>0)return;
 g->kill_count+=g->enemy_count;
 g->gold+=g->reward_gold+(relic(g,16)?12:0)+(relic(g,27)?5:0);
 if(relic(g,0))heal(g,6);
 if(g->battle_type==NODE_ELITE&&relic(g,12))g->permanent_strength++;
 if(g->battle_type==NODE_BOSS){
  if(g->act==3){g->screen=VICTORY;msg(g,"THE SPIRE HAS FALLEN");return;}
  for(int i=0;i<3;i++){
   int r=0,tries=0;
   do { r=random_relic(g); if(r<0)break;tries++; }
   while(tries<100&&((i>0&&r==g->reward[0])||(i>1&&r==g->reward[1])));
   g->reward[i]=r;
  }
  g->selection=0;g->screen=BOSS_REWARD;
  msg(g,"The guardian falls. Claim a power.");
  return;
 }
 fill_rewards(g);if(g->potion_count<MAX_POTIONS&&rnd(g,100)<22)g->potions[g->potion_count++]=rnd(g,6);g->screen=REWARD;g->selection=0;
 msg(g,"Victory! Choose one reward.");
}
/* Thirty-six deterministic, species-specific enemy profiles, balanced by act. */
typedef struct {const char *name;short hp,attack,tier; unsigned char moves[4];} EnemyDef;
static const EnemyDef enemy_defs[ENEMY_COUNT]={
 {"Ash Crawler",30,8,0,{0,0,1,6}},
 {"Bone Sentinel",35,8,0,{0,1,7,0}},
 {"Mist Gazer",32,9,0,{0,2,0,9}},
 {"Iron Wight",38,9,0,{0,3,1,0}},
 {"Grave Knight",53,11,0,{0,1,10,0}},
 {"Scorch Witch",50,12,0,{5,0,6,1}},
 {"Stone Giant",87,13,1,{1,10,0,4}},
 {"Fallen Warden",155,18,1,{7,3,4,0}},
 {"THE HOLLOW KING",300,23,2,{4,10,11,7}},
 {"Cinder Hound",33,9,0,{7,0,6,0}},
 {"Crypt Archer",37,9,0,{0,3,0,1}},
 {"Glimmer Moth",29,8,0,{8,2,0,9}},
 {"Oathbreaker",42,10,0,{4,0,0,10}},
 {"Ember Seer",78,12,1,{5,6,9,10}},
 {"Bone Captain",85,11,1,{11,7,4,3}},
 {"THE FURNACE MAW",168,15,2,{6,10,4,7}},
 {"Rust Reaver",56,12,0,{0,10,1,0}},
 {"Sable Lurker",52,12,0,{7,8,0,2}},
 {"Mire Oracle",50,11,0,{6,9,5,0}},
 {"Wound Collector",62,12,0,{12,0,3,4}},
 {"Chain Keeper",66,14,0,{8,0,1,7}},
 {"Ashborne Monk",53,12,0,{13,2,0,9}},
 {"Ossuary Beast",126,15,1,{10,7,6,1}},
 {"Storm Golem",143,16,1,{13,10,4,0}},
 {"THE CRIMSON JUDGE",240,19,2,{3,10,11,4}},
 {"Void Disciple",82,17,0,{5,8,0,1}},
 {"Bone Harvester",92,17,0,{7,0,12,3}},
 {"Abyss Watcher",78,16,0,{6,9,2,10}},
 {"Rift Channeler",79,16,0,{11,5,9,0}},
 {"Pale Executioner",103,18,0,{10,0,3,1}},
 {"Crownless Saint",91,16,0,{13,12,3,0}},
 {"Entropy Knight",102,19,0,{0,4,7,10}},
 {"Twilight Shade",88,18,0,{8,6,2,7}},
 {"Infernal Colossus",173,19,1,{4,10,6,0}},
 {"Spectral Marshal",163,19,1,{11,3,7,13}},
 {"Rift Behemoth",185,20,1,{10,6,4,7}},
};
/* Normal / elite / boss pools are separate so bosses never show up as ordinary foes. */
static const unsigned char enemy_normal[3][8]={{0,1,2,3,9,10,11,12},{4,5,16,17,18,19,20,21},{25,26,27,28,29,30,31,32}};
static const unsigned char enemy_elite[3][3]={{6,13,14},{7,22,23},{33,34,35}};
static const unsigned char enemy_boss[3]={15,24,8};
static void enemy_intent(Game*g,Enemy *e){
 const EnemyDef*d=&enemy_defs[e->art];
 if(d->tier==2 && e->phase==0 && e->hp*2<=e->maxhp){e->phase=1;e->strength+=3;}
 unsigned turn=(unsigned)g->turn;
 int slot=(int)(turn%4u);
 if(e->phase&&d->tier==2)slot=(slot+1)%4;
 e->intent=d->moves[slot];
 e->intent_value=(d->attack*85+50)/100+(g->floor>8?1:0)+(e->phase?2:0);
}
static void init_enemy(Game*g,Enemy*e,int id){
 const EnemyDef*d=&enemy_defs[id];
 memset(e,0,sizeof(*e));e->art=(short)id;
 snprintf(e->name,sizeof(e->name),"%s",d->name);
 e->maxhp=(short)((d->hp*(d->tier==2?80:85)+50)/100+(g->floor>8?3:0));
 e->hp=e->maxhp;
 enemy_intent(g,e);
}
const char *game_enemy_name(int id){return id>=0&&id<ENEMY_COUNT?enemy_defs[id].name:"Unknown";}
void game_start_battle(Game*g,int mode){
 g->screen=COMBAT;g->battle_type=mode;
 g->enemy_count=mode==NODE_BOSS?1:(mode==NODE_ELITE?1:(rnd(g,9)==0?2:1));
 for(int i=0;i<g->enemy_count;i++){
  int id=mode==NODE_BOSS?enemy_boss[g->act-1]:
    mode==NODE_ELITE?enemy_elite[g->act-1][rnd(g,3)]:
    enemy_normal[g->act-1][rnd(g,8)];
  init_enemy(g,&g->enemies[i],id);
 }
 g->turn=0;g->turn_played=0;g->selection=0;g->target=0;g->strength=g->permanent_strength+(relic(g,5)?1:0);g->low_hp_triggered=0;g->dexterity=relic(g,22)?1:0;
 g->weak=g->vulnerable=g->poison=g->block=0;
 g->reward_gold=(mode==NODE_BOSS?95:mode==NODE_ELITE?48:18)+rnd(g,12);
 if(relic(g,19))for(int i=0;i<g->enemy_count;i++)g->enemies[i].vulnerable=2;
 reshuffle_battle(g);msg(g,"The enemy is preparing an attack.");game_start_turn(g);
 if(relic(g,10))g->block+=8;
}
void game_start_turn(Game*g){
 if(g->screen!=COMBAT)return;
 g->turn++;
 g->energy=MAX(0,g->max_energy+(g->turn==1&&relic(g,1)?1:0)-g->energy_penalty);g->energy_penalty=0;
 if(relic(g,20)&&g->turn%3==0)heal(g,2);
 g->turn_played=0;
 if(relic(g,14)&&!g->low_hp_triggered&&g->hp*2<=g->maxhp){g->strength++;g->low_hp_triggered=1;}
 int n=5+(relic(g,18)?1:0)+(g->turn==1&&relic(g,7)?1:0)-(relic(g,25)?1:0);
 for(int i=0;i<n;i++)draw_card(g);
 g->selection=0;
}
void game_end_turn(Game*g){
 if(g->screen!=COMBAT)return;
 for(int i=0;i<g->hand_count;i++){
  if(CARD_ID(g->hand[i])==50)lose_hp(g,2);
  if(g->screen==DEFEAT)return;
  else if(CARD_ID(g->hand[i])==53)g->energy_penalty++;
  if(g->discard_count<MAX_PILE)g->discard[g->discard_count++]=g->hand[i];
 }
 g->hand_count=0;
 /* Block shields the incoming enemy turn, then expires before the next draw. */
 for(int k=0;k<g->enemy_count;k++){
  Enemy *e=&g->enemies[k];if(e->hp<=0)continue;
  e->block=0;
  if(e->poison){e->hp-=e->poison;e->poison=MAX(0,e->poison-1);}
  if(e->hp<=0)continue;
  switch(e->intent){
   case 0: {int dmg=MAX(0,e->intent_value+e->strength);if(e->weak)dmg=dmg*3/4;damage_player(g,dmg);break;}
   case 1:e->block+=e->intent_value;break;
   case 2:damage_player(g,MAX(0,e->intent_value/2+e->strength));g->weak=MAX(g->weak,2);break;
   case 3:damage_player(g,e->intent_value);g->vulnerable=MAX(g->vulnerable,2);break;
   case 4:e->strength+=2;e->block+=8;break;
   case 5:damage_player(g,e->intent_value/2);if(g->discard_count<MAX_PILE)g->discard[g->discard_count++]=50;break;
   case 6:damage_player(g,e->intent_value/2);g->poison=MIN(12,g->poison+2);break;
   case 7:for(int hit=0;hit<2&&g->screen==COMBAT;hit++)damage_player(g,MAX(1,e->intent_value/2+e->strength));break;
   case 8:damage_player(g,e->intent_value/2);g->energy_penalty=MIN(2,g->energy_penalty+1);break;
   case 9:e->hp=MIN(e->maxhp,e->hp+e->maxhp/9+3);e->block+=e->intent_value/2;break;
   case 10:damage_player(g,e->intent_value+e->intent_value/4+e->strength);if(g->discard_count<MAX_PILE)g->discard[g->discard_count++]=51;break;
   case 11:if(g->discard_count<MAX_PILE)g->discard[g->discard_count++]=53;e->block+=e->intent_value/2;break;
   case 12:{int before=g->hp;damage_player(g,e->intent_value/2+e->strength);e->hp=MIN(e->maxhp,e->hp+MAX(0,before-g->hp));break;}
   case 13:e->block+=e->intent_value;e->strength++;break;
  }
  if(g->screen==DEFEAT)return;
  if(e->weak>0)e->weak--;
  if(e->vulnerable>0)e->vulnerable--;
 }
 if(g->poison>0){lose_hp(g,g->poison);g->poison--;if(g->screen==DEFEAT)return;}
 if(g->weak>0)g->weak--;
 if(g->vulnerable>0)g->vulnerable--;
 check_win(g);
 if(g->screen!=COMBAT)return;
 g->block=0;
 for(int i=0;i<g->enemy_count;i++)if(g->enemies[i].hp>0)enemy_intent(g,&g->enemies[i]);
 game_start_turn(g);
}
static void all_damage(Game*g,int n){for(int i=0;i<g->enemy_count;i++)if(g->enemies[i].hp>0)deal(g,i,n);}
void game_play_card(Game*g,int index,int enemy){
 if(g->screen!=COMBAT||index<0||index>=g->hand_count)return;
 int raw=g->hand[index],id=CARD_ID(raw),up=CARD_UP(raw),cost=cards[id].cost;
 if(cost==-2)return;
 if(cost==-1)cost=g->energy;
 if(g->energy<cost)return;
 if(enemy<0||enemy>=g->enemy_count||g->enemies[enemy].hp<=0){enemy=0;while(enemy<g->enemy_count-1&&g->enemies[enemy].hp<=0)enemy++;}
 g->energy-=cost;
 g->hand_count--;
 for(int j=index;j<g->hand_count;j++)g->hand[j]=g->hand[j+1];
 int n=up?3:0;
 switch(id){
  case 0:deal(g,enemy,6+n);break;case 1:gain_block(g,5+n);break;
  case 2:deal(g,enemy,8+n);g->enemies[enemy].vulnerable+=2+up;break;
  case 3:all_damage(g,8+n);break;
  case 4:for(int j=0;j<2+up;j++)draw_card(g);break;
  case 5:gain_block(g,9+n);break;
  case 6:lose_hp(g,up?2:3);g->energy+=2+up;break;
  case 7:deal(g,enemy,15+2*n);break;
  case 8:g->strength+=2+up;break;
  case 9:gain_block(g,15+2*n);break;
  case 10:for(int j=0;j<cost;j++)all_damage(g,4+2*up);break;
  case 11:deal(g,enemy,7+n);draw_card(g);break;
  case 12:gain_block(g,7+n);deal(g,enemy,7+n);break;
  case 13:heal(g,3+up*2);deal(g,enemy,5+n);break;
  case 14:deal(g,enemy,4+n);g->enemies[enemy].weak+=2+up;break;
  case 15:deal(g,enemy,22+2*n);g->weak+=2-up;break;
  case 16:g->energy+=1+up;draw_card(g);break;
  case 17:gain_block(g,4+n);draw_card(g);break;
  case 18:g->strength+=3+up;lose_hp(g,5);break;
  case 19:deal(g,enemy,9+n);g->enemies[enemy].vulnerable+=3+up;break;
  case 20:heal(g,8+2*n);break;
  case 21:deal(g,enemy,g->block+up*5);break;
  case 22:for(int j=0;j<4+up;j++)deal(g,enemy,3);break;
  case 23:gain_block(g,12+n);g->dexterity+=1+up;break;
  case 24:gain_block(g,22+2*n);break;
  case 25:deal(g,enemy,7+n);heal(g,2+up);break;
  case 26:for(int j=0;j<3+up;j++)draw_card(g);if(g->hand_count>0){int x=g->hand[--g->hand_count];if(g->discard_count<MAX_PILE)g->discard[g->discard_count++]=x;}break;
  case 27:deal(g,enemy,5+n);deal(g,enemy,5+n);break;
  case 28:g->strength+=1+up;gain_block(g,8+n);break;
  case 29:deal(g,enemy,17+2*n);lose_hp(g,4);break;
  case 30:gain_block(g,4+n);gain_block(g,4+n);break;
  case 31:g->enemies[enemy].weak+=3+up;gain_block(g,3+n);break;
  case 32:g->enemies[enemy].block=0;deal(g,enemy,13+n);break;
  case 33:gain_block(g,5+n);draw_card(g);break;
  case 34:g->strength+=1+up;g->energy++;break;
  case 35:damage_enemy(g,enemy,9+n,1);break;
  case 36:all_damage(g,12+2*n);break;
  case 37:heal(g,5+up*2);gain_block(g,5+n);break;
  case 38:for(int j=0;j<3+up;j++)draw_card(g);lose_hp(g,2);break;
  case 39:deal(g,enemy,12+n);g->enemies[enemy].weak+=2+up;break;
  case 40:gain_block(g,7+n);g->strength+=1;break;
  case 41:gain_block(g,6+n);deal(g,enemy,6+n);break;
  case 42:deal(g,enemy,28+3*n);break;
  case 43:lose_hp(g,5);for(int j=0;j<4+up;j++)draw_card(g);break;
  case 44:deal(g,enemy,5+n);g->strength+=1;break;
  case 45:g->energy+=2+up;break;
  case 46:gain_block(g,20+2*n);lose_hp(g,3);break;
  case 47: {int was=g->enemies[enemy].hp;deal(g,enemy,11+n);if(was>0&&g->enemies[enemy].hp<=0)heal(g,5+3*up);break;}
  case 48:g->strength+=2+up;break;
  case 49:deal(g,enemy,6+n);g->enemies[enemy].vulnerable+=2+up;draw_card(g);break;
 }
 if(id==20||id==24||id==42||id==45||id==48){if(g->exhaust_count<MAX_PILE)g->exhaust[g->exhaust_count++]=raw;}
 else if(g->discard_count<MAX_PILE)g->discard[g->discard_count++]=raw;
 if(g->selection>=g->hand_count)g->selection=MAX(0,g->hand_count-1);
 g->turn_played++;
 if(g->hp<=0&&g->screen!=DEFEAT)g->screen=DEFEAT;
 if(g->screen==COMBAT)check_win(g);
}
const char *node_name(int type){static const char*names[]={"BATTLE","ELITE","MYSTERY","MERCHANT","CAMPFIRE","RELIC","BOSS"};return type>=0&&type<=6?names[type]:"UNKNOWN";}
static void encounter(Game*g,int node){
 g->selection=0;
 switch(node){
 case NODE_FIGHT:case NODE_ELITE:case NODE_BOSS:game_start_battle(g,node);break;
 case NODE_EVENT:g->screen=EVENT;g->effect_turn=rnd(g,12);msg(g,"A strange encounter. Choose your fate.");break;
 case NODE_SHOP:g->screen=SHOP;for(int i=0;i<3;i++)g->shop_cards[i]=card_reward(g);g->shop_relic=random_relic(g);break;
 case NODE_REST:g->screen=REST;break;
 case NODE_TREASURE:{int r=random_relic(g);if(r>=0){add_relic(g,r);snprintf(g->message,sizeof(g->message),"Found relic: %s",relic_defs[r].name);}else msg(g,"The chest was empty.");enter_map(g);break;}
 }
}
void game_choose_node(Game*g,int lane){
 if(g->screen!=MAP||g->floor>=MAP_ROWS)return;
 if(lane<0||lane>=MAP_LANES)return;
 if(g->floor>0&&abs(lane-g->lane)>1)return;
 g->lane=lane;g->map_selected[g->floor]=lane;
 int type=g->map[g->floor][lane];g->floor++;encounter(g,type);
}
void game_new(Game*g,uint32_t seed){
 memset(g,0,sizeof(*g));g->magic=0x52494654u;g->version=GAME_VERSION;
 g->seed=seed?seed:0x1affadeu;g->rng=g->seed;
 g->screen=TITLE;g->act=1;g->floor=0;g->lane=1;
 g->maxhp=g->hp=80;g->max_energy=3;g->gold=95;
 for(int i=0;i<5;i++)add_card(g,0);
 for(int i=0;i<4;i++)add_card(g,1);
 add_card(g,2);add_relic(g,0);
 g->potion_count=2;g->potions[0]=0;g->potions[1]=1;
 map_generate(g);msg(g,"A lone Warden climbs the ruined tower.");
}
void game_update(Game*g){(void)g;}
static void shop_buy(Game*g,int choice){
 int discount=relic(g,6)?15:0;
 if(choice<3){if(g->shop_cards[choice]<0){msg(g,"Already sold.");return;}int price=50+25*cards[g->shop_cards[choice]].rarity-discount;if(g->gold>=price&&g->deck_count<MAX_DECK){g->gold-=price;add_card(g,g->shop_cards[choice]);g->shop_cards[choice]=-1;msg(g,"Purchased a card.");}else msg(g,"Not enough gold.");}
 else if(choice==3){int price=155-discount;if(g->gold>=price&&g->shop_relic>=0){g->gold-=price;add_relic(g,g->shop_relic);g->shop_relic=-1;msg(g,"Relic purchased.");}else msg(g,"Not enough gold.");}
 else if(choice==4){if(g->gold>=45){g->gold-=45;heal(g,18);msg(g,"Restored 18 health.");}else msg(g,"Not enough gold.");}
 else if(choice==5){if(g->gold>=60&&g->deck_count>1){g->gold-=60;g->screen=DECK_VIEW;g->prior_screen=SHOP;g->selection=0;msg(g,"Choose a card to remove.");}else msg(g,"Not enough gold.");}
 else if(choice==6){enter_map(g);}
 else if(choice==7){if(g->gold>=50&&g->potion_count<MAX_POTIONS){g->gold-=50;g->potions[g->potion_count++]=rnd(g,6);msg(g,"Purchased a potion.");}else msg(g,"No funds or potion slots.");}
}
static void do_event(Game*g,int option){
 int n=g->effect_turn;
 if(option==1){enter_map(g);msg(g,"You move on quietly.");return;}
 switch(n){
 case 0:lose_hp(g,8);g->gold+=75;msg(g,"You seize a cursed purse: +75 gold, -8 HP.");break;
 case 1:heal(g,20);g->gold=MAX(0,g->gold-40);msg(g,"The spring restores you. It claims 40 coins.");break;
 case 2: if(g->deck_count<MAX_DECK)add_card(g,card_reward(g)|UPBIT);msg(g,"A forgotten lesson: gained an upgraded card.");break;
 case 3:g->maxhp+=5;heal(g,5);msg(g,"The ancient shrine increases your vitality.");break;
 case 4: {int r=random_relic(g);if(r>=0)add_relic(g,r);lose_hp(g,7);msg(g,"You take the relic, but the trap wounds you.");break;}
 case 5:g->gold+=30;heal(g,8);msg(g,"A friendly traveler shares a meal and coin.");break;
 case 6:add_card(g,card_reward(g));add_card(g,card_reward(g));lose_hp(g,10);msg(g,"Two weapons recovered, but the armory cuts deep.");break;
 case 7:g->maxhp+=10;lose_hp(g,17);msg(g,"The altar grants vitality for a blood sacrifice.");break;
 case 8:heal(g,28);add_card(g,52);msg(g,"The black water heals, leaving a lasting injury.");break;
 case 9:g->gold+=110;lose_hp(g,16);msg(g,"The gambit rewards greed with a terrible price.");break;
 case 10:for(int j=0;j<2;j++)if(g->deck_count){int idx=rnd(g,g->deck_count);g->deck[idx]|=UPBIT;}g->gold=MAX(0,g->gold-12);msg(g,"Two cards tempered at the ancient forge.");break;
 case 11:{int r=random_relic(g);if(r>=0)add_relic(g,r);add_card(g,53);msg(g,"An heirloom taken; a dreadful curse follows.");break;}
 }
 if(g->screen!=DEFEAT)enter_map(g);
}
static void rest_pick(Game*g,int option){
 if(option==0){heal(g,g->maxhp*3/10+(relic(g,8)?5:0));enter_map(g);msg(g,"Recovered at the campfire.");}
 if(option==1){g->screen=DECK_VIEW;g->prior_screen=REST;g->selection=0;g->scroll=0;msg(g,"Choose a card to upgrade.");}
}
static void use_potion(Game*g){
 if(g->screen!=COMBAT||g->potion_count<=0)return;
 int id=g->potions[--g->potion_count];int bonus=relic(g,17)?5:0;
 if(id==0)heal(g,18+bonus);
 if(id==1)g->strength+=2+(bonus>0);
 if(id==2)g->block+=20+bonus;
 if(id==3)all_damage(g,20+bonus);
 if(id==4)g->energy+=2;
 if(id==5){for(int i=0;i<3;i++)draw_card(g);}
 if(relic(g,21))g->block+=2;
 msg(g,"Potion used.");check_win(g);
}
void game_action(Game*g,int b){
 int n;
 switch(g->screen){
 case TITLE:
  if(b==BTN_OK){g->screen=MAP;msg(g,"Choose your first encounter.");}else if(b==BTN_ALT){g->screen=HELP;g->prior_screen=TITLE;}break;
 case HELP:if(b==BTN_BACK||b==BTN_OK)g->screen=g->prior_screen;break;
 case MAP:
  if(b==BTN_LEFT)g->selection=MAX(0,g->selection-1);
  else if(b==BTN_RIGHT)g->selection=MIN(2,g->selection+1);
  else if(b==BTN_OK){if(g->floor==MAP_ROWS){game_start_battle(g,NODE_BOSS);}else game_choose_node(g,g->selection);}
  else if(b==BTN_ALT){g->prior_screen=MAP;g->screen=DECK_VIEW;g->selection=0;g->scroll=0;}
  else if(b==BTN_START){g->prior_screen=MAP;g->screen=HELP;}
  break;
 case COMBAT:
  if(b==BTN_LEFT)g->selection=MAX(0,g->selection-1);
  else if(b==BTN_RIGHT)g->selection=MIN(MAX(0,g->hand_count-1),g->selection+1);
  else if(b==BTN_UP)g->target=(g->target+g->enemy_count-1)%g->enemy_count;
  else if(b==BTN_DOWN)g->target=(g->target+1)%g->enemy_count;
  else if(b==BTN_OK)game_play_card(g,g->selection,g->target);
  else if(b==BTN_BACK)game_end_turn(g);
  else if(b==BTN_POTION)use_potion(g);
  else if(b==BTN_ALT){g->prior_screen=COMBAT;g->screen=DECK_VIEW;g->selection=0;g->scroll=0;}
  break;
 case REWARD:
  if(b==BTN_LEFT)g->selection=MAX(0,g->selection-1);
  else if(b==BTN_RIGHT)g->selection=MIN(3,g->selection+1);
  else if(b==BTN_OK){if(g->selection<3)add_card(g,g->reward[g->selection]);enter_map(g);msg(g,"Onward, Warden.");}
  break;
 case REST:
  if(b==BTN_LEFT||b==BTN_RIGHT)g->selection=1-g->selection;
  else if(b==BTN_OK)rest_pick(g,g->selection);
  break;
 case SHOP:
  if(b==BTN_UP)g->selection=MAX(0,g->selection-1);
  else if(b==BTN_DOWN)g->selection=MIN(7,g->selection+1);
  else if(b==BTN_OK)shop_buy(g,g->selection);
  else if(b==BTN_BACK)enter_map(g);
  break;
 case EVENT:
  if(b==BTN_LEFT||b==BTN_RIGHT)g->selection=1-g->selection;
  else if(b==BTN_OK)do_event(g,g->selection);
  break;
 case DECK_VIEW:
  if(b==BTN_UP)g->selection=MAX(0,g->selection-1);
  else if(b==BTN_DOWN)g->selection=MIN(g->deck_count-1,g->selection+1);
  else if(b==BTN_BACK){
    if(g->prior_screen==MAP)enter_map(g);
    else{g->screen=g->prior_screen;g->selection=0;}
   }
  else if(b==BTN_OK){
   if(g->prior_screen==REST&&g->deck_count>0){g->deck[g->selection]|=UPBIT;enter_map(g);msg(g,"Card upgraded.");}
   else if(g->prior_screen==SHOP&&g->deck_count>1){n=g->selection;for(int i=n;i<g->deck_count-1;i++)g->deck[i]=g->deck[i+1];g->deck_count--;g->screen=SHOP;msg(g,"Card removed.");}
  }break;
 case BOSS_REWARD:
  if(b==BTN_LEFT)g->selection=MAX(0,g->selection-1);
  else if(b==BTN_RIGHT)g->selection=MIN(2,g->selection+1);
  else if(b==BTN_OK){
    if(g->reward[g->selection]>=0)add_relic(g,g->reward[g->selection]);
    heal(g,g->maxhp/3);
    g->act++;g->floor=0;g->lane=1;map_generate(g);enter_map(g);
    msg(g,"A new ascent begins. Choose a path.");
  }
  break;
 case VICTORY:case DEFEAT:
  if(b==BTN_OK){uint32_t seed=game_random(g);game_new(g,seed);}
  break;
 }
}
int game_validate(const Game*g){
 if(!g||g->magic!=0x52494654u||g->version!=GAME_VERSION)return 0;
 if(g->act<1||g->act>3||g->floor<0||g->floor>MAP_ROWS||g->lane<0||g->lane>=3)return 0;
 if(g->maxhp<=0||g->hp<0||g->hp>g->maxhp||g->gold<0)return 0;
 if(g->screen<TITLE||g->screen>BOSS_REWARD||g->deck_count<1||g->deck_count>MAX_DECK)return 0;
 if(g->hand_count<0||g->hand_count>MAX_HAND||g->draw_count<0||g->draw_count>MAX_PILE||g->discard_count<0||g->discard_count>MAX_PILE)return 0;
 if(g->enemy_count<0||g->enemy_count>MAX_ENEMIES||g->potion_count<0||g->potion_count>MAX_POTIONS)return 0;
 for(int i=0;i<g->enemy_count;i++)if(g->enemies[i].art<0||g->enemies[i].art>=ENEMY_COUNT||g->enemies[i].maxhp<1||g->enemies[i].hp>g->enemies[i].maxhp||g->enemies[i].intent<0||g->enemies[i].intent>13)return 0;
 if(g->relic_count<0||g->relic_count>MAX_RELICS)return 0;
 for(int i=0;i<g->deck_count;i++)if(CARD_ID(g->deck[i])>=CARD_COUNT)return 0;
 for(int i=0;i<g->hand_count;i++)if(CARD_ID(g->hand[i])>=CARD_COUNT)return 0;
 for(int i=0;i<g->relic_count;i++)if(g->relics[i]<0||g->relics[i]>=RELIC_COUNT)return 0;
 for(int i=0;i<g->potion_count;i++)if(g->potions[i]<0||g->potions[i]>5)return 0;
 for(int r=0;r<MAP_ROWS;r++)for(int c=0;c<MAP_LANES;c++)if(g->map[r][c]<NODE_FIGHT||g->map[r][c]>NODE_BOSS)return 0;
 if(g->screen==MAP&&(g->selection<0||g->selection>=MAP_LANES))return 0;
 if(g->screen==COMBAT&&(g->selection<0||g->selection>=MAX(1,g->hand_count)||g->target<0||g->target>=MAX(1,g->enemy_count)))return 0;
 if(g->screen==REWARD&&(g->selection<0||g->selection>3))return 0;
 if(g->screen==BOSS_REWARD&&(g->selection<0||g->selection>2))return 0;
 if(g->screen==REST&&(g->selection<0||g->selection>1))return 0;
 if(g->screen==EVENT&&(g->selection<0||g->selection>1||g->effect_turn<0||g->effect_turn>11))return 0;
 if(g->screen==SHOP&&(g->selection<0||g->selection>7))return 0;
 if(g->screen==DECK_VIEW&&(g->selection<0||g->selection>=g->deck_count))return 0;
 if(g->screen==REWARD)for(int i=0;i<3;i++)if(CARD_ID(g->reward[i])>=CARD_COUNT-4)return 0;
 if(g->screen==BOSS_REWARD)for(int i=0;i<3;i++)if(g->reward[i]<-1||g->reward[i]>=RELIC_COUNT)return 0;
 return 1;
}
/* Save is a checksummed snapshot: reject truncated/corrupted or incompatible saves. */
static uint32_t hash_bytes(const unsigned char*p,size_t n){uint32_t h=2166136261u;for(size_t i=0;i<n;i++)h=(h^p[i])*16777619u;return h;}
int game_save(const Game*g,const char*path){if(!game_validate(g))return 0;FILE*f=fopen(path,"wb");if(!f)return 0;uint32_t check=hash_bytes((const unsigned char*)g,sizeof(*g));int ok=fwrite(&check,4,1,f)==1&&fwrite(g,sizeof(*g),1,f)==1;return fclose(f)==0&&ok;}
int game_load(Game*g,const char*path){Game temp;uint32_t check;FILE*f=fopen(path,"rb");if(!f)return 0;int ok=fread(&check,4,1,f)==1&&fread(&temp,sizeof(temp),1,f)==1;fclose(f);if(!ok||check!=hash_bytes((const unsigned char*)&temp,sizeof(temp))||!game_validate(&temp))return 0;*g=temp;return 1;}

/* Persistent, versioned lifetime profile. One result per unique run seed. */
void profile_init(RiftProfile*p){
 memset(p,0,sizeof(*p));p->magic=0x52415046u;p->version=1;
}
static int profile_valid(const RiftProfile*p){
 return p&&p->magic==0x52415046u&&p->version==1&&
  p->wins<=p->runs&&p->losses<=p->runs&&p->wins+p->losses==p->runs&&
  p->furthest_floor<=39;
}
int profile_record(RiftProfile*p,const Game*g){
 if(!profile_valid(p)||!g||(g->screen!=VICTORY&&g->screen!=DEFEAT))return 0;
 if(p->runs&&p->last_seed==g->seed&&p->last_result==(uint32_t)g->screen)return 0;
 p->runs++;
 if(g->screen==VICTORY)p->wins++;else p->losses++;
 unsigned distance=g->screen==VICTORY?39u:(unsigned)((g->act-1)*13+g->floor);
 if(distance>p->furthest_floor)p->furthest_floor=distance;
 if(g->kill_count>0)p->total_kills+=(uint32_t)g->kill_count;
 if(g->kill_count>(int)p->best_kills)p->best_kills=(uint32_t)g->kill_count;
 if(g->deck_count>(int)p->best_deck)p->best_deck=(uint32_t)g->deck_count;
 p->last_seed=g->seed;p->last_result=(uint32_t)g->screen;
 return 1;
}
int profile_save(const RiftProfile*p,const char*path){
 if(!profile_valid(p))return 0;
 FILE*f=fopen(path,"wb");if(!f)return 0;
 uint32_t checksum=hash_bytes((const unsigned char*)p,sizeof(*p));
 int ok=fwrite(&checksum,sizeof(checksum),1,f)==1&&fwrite(p,sizeof(*p),1,f)==1;
 return fclose(f)==0&&ok;
}
int profile_load(RiftProfile*p,const char*path){
 RiftProfile stored;uint32_t checksum;
 FILE*f=fopen(path,"rb");if(!f)return 0;
 int ok=fread(&checksum,sizeof(checksum),1,f)==1&&fread(&stored,sizeof(stored),1,f)==1;
 if(fclose(f)!=0)ok=0;
 if(!ok||checksum!=hash_bytes((const unsigned char*)&stored,sizeof(stored))||!profile_valid(&stored))return 0;
 *p=stored;return 1;
}
