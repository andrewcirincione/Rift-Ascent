# Backward-compatible entry point for the parent Windows one-click build pipeline.
# It deliberately uses the SAME validated build script as BUILD_EBOOT.cmd.
$ErrorActionPreference = 'Stop'
$pipeline = Join-Path (Split-Path -Parent $PSScriptRoot) 'tools\Build-RiftAscent.ps1'
if (-not (Test-Path -LiteralPath $pipeline -PathType Leaf)) {
    throw 'The full one-click builder is required. Extract the complete ZIP and run BUILD_EBOOT.cmd at its root.'
}
& $pipeline
if ($LASTEXITCODE -ne 0) { throw "Rift Ascent build failed. Check OUTPUT\BUILD_LOG.txt (exit $LASTEXITCODE)." }
Write-Host 'Build complete; review OUTPUT\BUILD_REPORT.txt for emulator test status.'
