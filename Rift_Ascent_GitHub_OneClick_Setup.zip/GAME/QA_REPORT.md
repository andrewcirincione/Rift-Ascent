# Rift Ascent final local QA — October 2026

**Actual results, not projected hardware results.**

| Verification | Result |
|---|---|
| 36 enemy species, every species encounterable in its correct act | PASS |
| 3 different, act-exclusive bosses, 9 elite enemy encounters | PASS |
| All 14 distinct combat intents execute without invalid states | PASS |
| 36 distinct 104×110 transparent RGBA runtime sprites / embedded RGB565 arrays | PASS |
| 12 event variants, three-act map and reward flow | PASS in host progression tests |
| 50 playable cards × base/upgraded (100 variants) | PASS |
| 201 full deterministic three-act simulations | PASS |
| 500 randomized controller sequences | PASS |
| 2,000 seeded full controller-driven AI playthroughs | PASS; 385 victories on latest balance |
| Save/load and persistent profile integrity / corrupt-file rejection | PASS |
| Native-resolution renderer screenshots and frame animation tests | PASS (desktop code) |
| PSP front end against firmware mocks | PASS, 14 frames |
| C to MIPS-II object compilation, seven modules | PASS (Clang cross-target + mock headers) |
| EBOOT validator rejects 14 damaged ELF/PBP examples | PASS |
| Official PSPDEV compile and EBOOT link | **NOT TESTED: unavailable compiler** |
| Real EBOOT boot in PPSSPP | **NOT TESTED: emulator unavailable** |
| Real PSP hardware boot, save and sustained FPS | **NOT TESTED: no hardware** |

Memory reference: 36 RGB565 104×110 enemy images occupy 823,680 bytes in the final executable. The entire seven-module MIPS object set is about 2.6 MB before final linking, and PSP double 32-bit framebuffers use 1,114,112 bytes of 2 MB VRAM. This does not measure runtime FPS or certify successful PSP linking.

The automated AI wins are not a human difficulty benchmark; the run agent uses simple card-ranking heuristics. Different user play styles may achieve different results.

## Native PSP testing still required

1. Compile with the official `pspdev/pspdev:v20261001` compiler in the one-click pipeline.
2. Launch the **packed EBOOT.PBP** in PPSSPP and check controls, combat, save/load, graphics, audio, and all three act transitions.
3. Run on a homebrew-capable PSP-1000 with a physical memory stick; measure sustained frame rate and test suspend/resume.

No claim of a working physical PSP release is made until these steps succeed.
