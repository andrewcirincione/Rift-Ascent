#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p /tmp/rift_mips_check
RESOURCE="$(clang -print-resource-dir)/include"
for file in src/game.c src/render.c src/artwork.c src/motion_art.c src/enemy_art.c src/psp_main.c src/sound.c; do
 clang --target=mipsel-unknown-elf -march=mips2 -mabi=32 -ffreestanding -fno-pic -fno-builtin -G0 -O2 -Wall -Wextra -Werror \
 -nostdinc -isystem "$RESOURCE" -Itests/mock_libc -Itests/mock_psp -Isrc -c "$file" -o "/tmp/rift_mips_check/$(basename "$file" .c).o"
done
file /tmp/rift_mips_check/*.o
