#!/usr/bin/env python3
from pathlib import Path
from PIL import Image
root=Path(__file__).resolve().parents[1]
imgs=[]
for i in range(36):
 p=root/'assets/runtime'/f'enemy_{i:02d}.png'
 with Image.open(p) as im:
  assert im.size==(104,110) and im.mode=='RGBA' and im.getbbox(), f'Invalid sprite {i}'
  imgs.append(im.copy().tobytes())
assert len(set(imgs))==36,'Not all sprite variants are distinct'
body=(root/'src/enemy_art.c').read_text()
for i in range(36):assert f'const uint16_t rift_enemy_{i}[' in body
for p in (root/'assets/runtime').glob('*.png'):
 with Image.open(p) as im:im.verify()
print('PASS: 36 distinct 104x110 sprite RGBA assets, all compiled sprites, and all runtime PNGs valid')
