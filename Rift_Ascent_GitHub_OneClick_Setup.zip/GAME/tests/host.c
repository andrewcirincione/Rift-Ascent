#include "../src/game.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <assert.h>
#include <sys/stat.h>
#include <sys/types.h>
static void screenshot(const Game*g,const char*name){
 static uint32_t pixels[W*H];game_render(g,pixels,W);
 char path[240];snprintf(path,sizeof(path),"screenshots/%s.ppm",name);
 FILE*f=fopen(path,"wb");if(!f)return;
 fprintf(f,"P6\n%d %d\n255\n",W,H);
 for(int j=0;j<H;j++)for(int i=0;i<W;i++){uint32_t c=pixels[j*W+i];fputc((int)(c&255),f);fputc((int)((c>>8)&255),f);fputc((int)((c>>16)&255),f);}fclose(f);
}
static int simulate_run(int seed,int shots){
 Game g;game_new(&g,(uint32_t)seed);assert(game_validate(&g));
 if(shots)screenshot(&g,"01_title");game_action(&g,BTN_OK);
 if(shots)screenshot(&g,"02_map");
 int encounters=0,bosses=0;
 for(int act=1;act<=3;act++){
  assert(g.act==act);
  for(int floor=0;floor<MAP_ROWS;floor++){
   assert(g.screen==MAP);
   int lane=1;g.selection=lane;game_choose_node(&g,lane);encounters++;
   if(g.screen==COMBAT){
    if(shots&&encounters==1)screenshot(&g,"03_combat");
    for(int i=0;i<g.enemy_count;i++)g.enemies[i].hp=0;
    game_end_turn(&g);
    assert(g.screen==REWARD);
    if(shots&&encounters==1)screenshot(&g,"04_reward");
    game_action(&g,BTN_OK);
   }else if(g.screen==SHOP){
    if(shots)screenshot(&g,"06_shop");
    game_action(&g,BTN_BACK);
   }else if(g.screen==REST){
    if(shots)screenshot(&g,"07_rest");
    g.selection=0;game_action(&g,BTN_OK);
   }else if(g.screen==EVENT){
    if(shots)screenshot(&g,"05_event");
    g.selection=1;game_action(&g,BTN_OK);
   }
   assert(g.screen==MAP);
   assert(game_validate(&g));
   assert(g.floor==floor+1);
   if(floor==6){char save[70]="/tmp/rift_test_save.dat";Game loaded;
    assert(game_save(&g,save));assert(game_load(&loaded,save));assert(memcmp(&g,&loaded,sizeof(Game))==0);remove(save);
   }
  }
  g.selection=1;game_action(&g,BTN_OK);assert(g.screen==COMBAT);bosses++;
  for(int i=0;i<g.enemy_count;i++)g.enemies[i].hp=0;
  game_end_turn(&g);
  if(act<3){assert(g.screen==BOSS_REWARD);game_action(&g,BTN_OK);assert(g.screen==MAP);}else assert(g.screen==VICTORY);
 }
 if(shots)screenshot(&g,"08_victory");
 assert(encounters==36&&bosses==3);
 return 1;
}
static void test_combat_rules(void){
 Game g;game_new(&g,999);g.screen=MAP;game_start_battle(&g,NODE_FIGHT);
 g.hp=80;g.enemy_count=1;g.enemies[0].hp=999;g.enemies[0].maxhp=999;
 g.enemies[0].intent=0;g.enemies[0].intent_value=13;g.enemies[0].weak=0;
 g.hand_count=0;g.block=12;game_end_turn(&g);
 assert(g.hp==79);assert(g.block==0);assert(g.screen==COMBAT);
 g.hand_count=1;g.hand[0]=6;g.block=40;g.hp=70;g.energy=3;
 game_play_card(&g,0,0);assert(g.hp==67);assert(g.block==40);
 g.hand_count=1;g.hand[0]=50;g.block=40;g.enemies[0].intent=1;
 int oldhp=g.hp;game_end_turn(&g);assert(g.hp==oldhp-2);
 assert(game_validate(&g));
}
static void test_views_and_corruption(void){
 Game g;game_new(&g,777);game_action(&g,BTN_OK);
 g.screen=DECK_VIEW;g.prior_screen=MAP;g.selection=2;screenshot(&g,"09_deck");
 g.screen=BOSS_REWARD;g.selection=1;g.reward[0]=3;g.reward[1]=11;g.reward[2]=18;screenshot(&g,"10_boss_relics");
 g.screen=DEFEAT;g.hp=0;screenshot(&g,"11_defeat");
 g.hp=80;g.screen=MAP;
 const char*path="/tmp/rift_corruption_test.dat";
 assert(game_save(&g,path));
 FILE*f=fopen(path,"r+b");assert(f);assert(fseek(f,25,SEEK_SET)==0);fputc(0xff,f);fclose(f);
 Game loaded;assert(!game_load(&loaded,path));remove(path);
 static uint32_t pixels[W*H];
 for(int screen=TITLE;screen<=BOSS_REWARD;screen++){
   g.screen=screen;g.selection=0;g.effect_turn=0;g.hp=80;
   if(screen==COMBAT)game_start_battle(&g,NODE_FIGHT);
   game_render(&g,pixels,W);
 }
}
static void test_profile_persistence(void){
 RiftProfile p,loaded;profile_init(&p);
 Game g;game_new(&g,1234);g.screen=VICTORY;
 g.act=3;g.floor=12;g.kill_count=14;
 assert(profile_record(&p,&g));assert(p.runs==1&&p.wins==1&&p.furthest_floor==39);
 assert(!profile_record(&p,&g));assert(p.runs==1);
 assert(profile_save(&p,"/tmp/rift_profile_test.dat"));
 profile_init(&loaded);
 assert(profile_load(&loaded,"/tmp/rift_profile_test.dat"));
 assert(memcmp(&p,&loaded,sizeof(p))==0);
 g.seed=1235;g.screen=DEFEAT;g.act=2;g.floor=6;
 assert(profile_record(&loaded,&g));
 assert(loaded.runs==2&&loaded.wins==1&&loaded.losses==1);
 FILE*f=fopen("/tmp/rift_profile_test.dat","r+b");assert(f);
 assert(fseek(f,5,SEEK_SET)==0);fputc(0xff,f);fclose(f);
 assert(!profile_load(&p,"/tmp/rift_profile_test.dat"));
 remove("/tmp/rift_profile_test.dat");
}
static void stress_cards(void){
 Game base;game_new(&base,123);base.screen=MAP;game_start_battle(&base,NODE_BOSS);
 for(int id=0;id<CARD_COUNT-4;id++)for(int up=0;up<2;up++){
  Game g=base;g.screen=COMBAT;g.hp=g.maxhp=1000;g.energy=99;
  g.enemy_count=1;g.enemies[0].hp=g.enemies[0].maxhp=10000;
  g.hand_count=1;g.hand[0]=id|(up?UPBIT:0);g.turn_played=0;
  game_play_card(&g,0,0);assert(game_validate(&g));
 }
}
static void fuzz_controls(void){
 for(unsigned seed=1;seed<=500;seed++){
  Game g;game_new(&g,seed);game_action(&g,BTN_OK);
  for(int i=0;i<200;i++){
   int buttons[]={BTN_UP,BTN_DOWN,BTN_LEFT,BTN_RIGHT,BTN_OK,BTN_BACK,BTN_ALT,BTN_POTION};
   int b=buttons[game_random(&g)%8];
   game_action(&g,b);
   if(g.screen==DEFEAT)break;
   if(!game_validate(&g)){fprintf(stderr,"BAD seed %u step %d screen %d selection %d hand %d deck %d target %d enemy %d floor %d potion %d\n",seed,i,g.screen,g.selection,g.hand_count,g.deck_count,g.target,g.enemy_count,g.floor,g.potion_count);abort();}
  }
 }
}
int main(int argc,char**argv){
 (void)argc;(void)argv;
 simulate_run(4671,1);
 for(int i=1;i<=200;i++)simulate_run(i*13837,0);
 stress_cards();
 test_combat_rules();
 test_profile_persistence();
 test_views_and_corruption();
 fuzz_controls();
 puts("PASS: 201 full 3-act runs, 100 card variants, 500 input fuzz streams, 12 UI screens, save/profile integrity checks");
 return 0;
}
