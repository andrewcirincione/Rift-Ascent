#!/usr/bin/env python3
"""Adversarial tests for the portable PBP/ELF structure checker.

Uses a deliberately tiny synthetic MIPS ELF solely to exercise the parser.
It does not claim the synthetic executable is PSP-runnable.
"""
import sys
import struct
from pathlib import Path
from tempfile import TemporaryDirectory
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from verify_eboot import check, InvalidEboot


def u32(buf, off, val):
    struct.pack_into('<I', buf, off, val)


def synthetic():
    elf = bytearray(512)
    elf[:7] = b'\x7fELF\x01\x01\x01'
    struct.pack_into('<HHI', elf, 16, 2, 8, 1)
    struct.pack_into('<II', elf, 24, 0x08804000, 52)
    struct.pack_into('<HHH', elf, 40, 52, 32, 1)
    struct.pack_into('<IIIIIIII', elf, 52, 1, 128, 0x08804000, 0x08804000, 100, 200, 7, 16)
    sfo = b'\x00PSF' + bytes(28)
    png = b'\x89PNG\r\n\x1a\n' + bytes(40)
    sections = [sfo, png, b'', b'', b'', b'', elf, b'']
    offs = []
    curr = 40
    for sec in sections:
        offs.append(curr)
        curr += len(sec)
    header = b'\x00PBP' + struct.pack('<I', 0x10000) + struct.pack('<8I', *offs)
    return bytearray(header + b''.join(sections))


with TemporaryDirectory() as td:
    path = Path(td) / 'EBOOT.PBP'
    good = synthetic()
    path.write_bytes(good)
    result = check(path)
    assert result['segments'] == 1
    assert result['static_memory'] == 200
    offsets = struct.unpack_from('<8I', good, 8)
    bad = []
    def mutation(label, fun):
        buf = good.copy()
        fun(buf)
        bad.append((label, buf))
    mutation('header magic', lambda b: b.__setitem__(0, 1))
    mutation('PBP version', lambda b: u32(b, 4, 3))
    mutation('SFO header', lambda b: b.__setitem__(40, 70))
    mutation('icon signature', lambda b: b.__setitem__(offsets[1], 0))
    mutation('offsets inverted', lambda b: u32(b, 8+4*5, 90000))
    mutation('missing ELF', lambda b: b.__setitem__(offsets[6], 0))
    mutation('ELF wrong endian', lambda b: b.__setitem__(offsets[6]+5, 2))
    mutation('ELF wrong architecture', lambda b: b.__setitem__(offsets[6]+18, 0))
    mutation('ELF no entry point', lambda b: u32(b, offsets[6]+24, 0))
    mutation('ELF entry unmapped', lambda b: u32(b, offsets[6]+24, 0x08840000))
    mutation('ELF entry nonexecutable', lambda b: u32(b, offsets[6]+52+24, 6))
    mutation('ELF load unaligned', lambda b: u32(b, offsets[6]+52+28, 23))
    mutation('ELF bad program offset', lambda b: u32(b, offsets[6]+28, 30000))
    mutation('ELF bad load segment', lambda b: u32(b, offsets[6]+52+4, 30000))
    mutation('ELF file size exceeds memory', lambda b: u32(b, offsets[6]+52+20, 0))
    mutation('ELF too large memory', lambda b: u32(b, offsets[6]+52+20, 32*1024*1024))
    bad.append(('truncated file', good[:40]))
    for label, buf in bad:
        path.write_bytes(buf)
        try:
            check(path)
        except InvalidEboot:
            pass
        else:
            raise AssertionError(f'Bad EBOOT accepted: {label}')
print(f'PASS: 1 valid synthetic envelope; {len(bad)} corrupted PBP/ELF variants rejected')
