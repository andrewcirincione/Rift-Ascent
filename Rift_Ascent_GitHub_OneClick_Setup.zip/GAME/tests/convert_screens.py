from pathlib import Path
from PIL import Image
for p in Path('screenshots').glob('*.ppm'):
    Image.open(p).save(p.with_suffix('.png'))
    p.unlink()
print('Created',len(list(Path('screenshots').glob('*.png'))),'screenshots')
