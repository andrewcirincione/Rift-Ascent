#ifndef RIFT_CROSS_STRING_H
#define RIFT_CROSS_STRING_H
#include <stddef.h>
void *memcpy(void*,const void*,size_t);
void *memset(void*,int,size_t);
size_t strlen(const char*);
#endif
