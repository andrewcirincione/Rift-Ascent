#ifndef RIFT_CROSS_STDIO_H
#define RIFT_CROSS_STDIO_H
#include <stddef.h>
typedef struct RiftFILE FILE;
FILE *fopen(const char*,const char*);
int fclose(FILE*);
size_t fread(void*,size_t,size_t,FILE*);
size_t fwrite(const void*,size_t,size_t,FILE*);
int snprintf(char*,size_t,const char*,...);
int remove(const char*);
#endif
