#ifndef RIFT_CROSS_STDLIB_H
#define RIFT_CROSS_STDLIB_H
int abs(int);
#endif
