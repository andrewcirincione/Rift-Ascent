#include "../src/game.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

/* Roster, level progression and the complete enemy intent vocabulary. */
int main(void){
 const int bosses[3]={15,24,8};
 int seen[ENEMY_COUNT]={0}, move_seen[14]={0};
 for(int act=1;act<=3;act++){
  Game boss;game_new(&boss,(unsigned)act*319u);boss.act=act;boss.floor=MAP_ROWS;
  game_start_battle(&boss,NODE_BOSS);
  assert(boss.screen==COMBAT && boss.enemy_count==1);
  assert(boss.enemies[0].art==bosses[act-1]);
  assert(game_validate(&boss));
  seen[bosses[act-1]]=1;
  for(int seed=1;seed<=1500;seed++){
   Game g;game_new(&g,(unsigned)seed*101u+act);g.act=act;g.floor=seed%MAP_ROWS;
   game_start_battle(&g,seed%4==0?NODE_ELITE:NODE_FIGHT);
   assert(g.enemy_count>=1&&g.enemy_count<=MAX_ENEMIES&&game_validate(&g));
   for(int k=0;k<g.enemy_count;k++){
    int id=g.enemies[k].art;
    assert(id>=0 && id<ENEMY_COUNT);
    assert(strcmp(game_enemy_name(id),g.enemies[k].name)==0);
    assert(id!=bosses[act-1]);
    seen[id]=1;
   }
  }
 }
 for(int i=0;i<ENEMY_COUNT;i++){
  if(!seen[i])fprintf(stderr,"Enemy %d never appears: %s\n",i,game_enemy_name(i));
  assert(seen[i]);
 }
 for(int id=0;id<ENEMY_COUNT;id++){
  for(int t=0;t<16;t++){
   Game g;game_new(&g,(unsigned)id*333u+t+1);
   g.act=id==8?3:id==15?1:id==24?2:1;
   game_start_battle(&g,NODE_BOSS);
   /* Exercise every enemy definition, not only the selected boss pool. */
   g.enemies[0].art=id;g.enemies[0].hp=g.enemies[0].maxhp=500;
   g.hp=g.maxhp=999;g.enemies[0].intent=t%14;g.enemies[0].intent_value=10;
   move_seen[t%14]++;
   game_end_turn(&g);
   assert(g.screen==COMBAT && game_validate(&g));
   assert(g.turn==2);
  }
 }
 for(int i=0;i<14;i++)assert(move_seen[i]);
 puts("PASS: all 36 enemy species encounterable, boss-exclusive pools, 14 live intent actions, and state integrity");
 return 0;
}
