#!/usr/bin/env python3
"""Offline extraction of PSP 16-bit chromakey sprites from original scene art.
Run after generate_artwork.py. Runtime is decoder-free: no PNG and no masks read.
"""
from pathlib import Path
import cv2
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
src=ROOT/'assets/runtime/combat_bg.png'
im=np.array(Image.open(src).convert('RGB'))
objects=[
 ('hero',[(17,150),(29,133),(54,112),(72,96),(91,82),(111,72),(114,52),(121,78),(127,92),(143,98),(149,82),(164,86),(170,104),(145,119),(135,147),(133,165),(102,168),(88,162),(45,159)],[(72,143),(108,93),(120,106),(121,147),(92,149)]),
 ('wight',[(306,164),(311,133),(316,105),(326,77),(330,47),(341,77),(356,66),(368,48),(375,81),(383,97),(405,161)],[(326,149),(331,88),(346,100),(368,94),(382,149)])
]
maskall=np.zeros(im.shape[:2],np.uint8)
art=[]
for name,outer,inner in objects:
 mask=np.zeros(im.shape[:2],np.uint8)
 cv2.fillPoly(mask,[np.array(outer,np.int32)],cv2.GC_PR_FGD)
 cv2.fillPoly(mask,[np.array(inner,np.int32)],cv2.GC_FGD)
 x,y,w,h=cv2.boundingRect(np.array(outer,np.int32))
 x=max(0,x-5);y=max(0,y-5);w=min(im.shape[1]-x,w+10);h=min(im.shape[0]-y,h+10)
 cv2.grabCut(im,mask,(x,y,w,h),np.zeros((1,65),np.float64),np.zeros((1,65),np.float64),5,cv2.GC_INIT_WITH_MASK)
 alpha=np.where((mask==cv2.GC_FGD)|(mask==cv2.GC_PR_FGD),255,0).astype(np.uint8)
 alpha=cv2.morphologyEx(alpha,cv2.MORPH_CLOSE,np.ones((3,3),np.uint8))
 alpha=cv2.medianBlur(alpha,3)
 alpha[172:]=0
 maskall=np.maximum(maskall,alpha)
 arr=np.concatenate([im[y:y+h,x:x+w],alpha[y:y+h,x:x+w,None]],axis=2)
 Image.fromarray(arr).save(ROOT/f'assets/runtime/{name}_sprite.png')
 art.append((name,x,y,w,h,arr))
clean=cv2.inpaint(im,maskall,9,cv2.INPAINT_TELEA)
Image.fromarray(clean).save(ROOT/'assets/runtime/combat_clean.png')
art.insert(0,('combat_clean',0,0,480,272,np.concatenate([clean,np.ones((272,480,1),dtype=np.uint8)*255],axis=2)))
head=['#ifndef RIFT_MOTION_ART_H','#define RIFT_MOTION_ART_H','#include <stdint.h>','#define RIFT_TRANSPARENT_565 0xf81f']
body=['#include "motion_art.h"']
for name,x,y,w,h,data in art:
 ident='rift_'+name
 head.append(f'#define {ident.upper()}_X {x}')
 head.append(f'#define {ident.upper()}_Y {y}')
 head.append(f'#define {ident.upper()}_W {w}')
 head.append(f'#define {ident.upper()}_H {h}')
 head.append(f'extern const uint16_t {ident}[{w*h}];')
 rgb=data[:,:,:3].astype(np.uint16)
 pix=((rgb[:,:,0]>>3)<<11)|((rgb[:,:,1]>>2)<<5)|(rgb[:,:,2]>>3)
 pix=np.where(data[:,:,3]>127,pix,0xf81f).astype(np.uint16)
 # An opaque pixel that matches the key is remapped to a neighbor color.
 pix[(pix==0xf81f)&(data[:,:,3]>127)]=0xf01e
 buf=pix.ravel()
 body.append('const uint16_t '+ident+f'[{w*h}] = {{')
 for j in range(0,len(buf),20):body.append(','.join('0x%04x'%int(v) for v in buf[j:j+20])+',')
 body.append('};')
head.append('#endif')
(ROOT/'src/motion_art.h').write_text('\n'.join(head)+'\n')
(ROOT/'src/motion_art.c').write_text('\n'.join(body)+'\n')
print('Generated motion art:', [(a[0],a[3],a[4]) for a in art])
