#!/usr/bin/env python3
"""Compatibility wrapper: generate the complete 36-enemy sprite atlas."""
import runpy
from pathlib import Path
runpy.run_path(str(Path(__file__).with_name("expand_enemy_art.py")),run_name="__main__")
