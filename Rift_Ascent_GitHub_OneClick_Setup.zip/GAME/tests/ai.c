#include "../src/game.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static int node_score(const Game*g,int n){
 int hp=g->hp*100/g->maxhp;
 switch(n){case NODE_REST:return hp<90?180:20;case NODE_TREASURE:return 130;case NODE_EVENT:return hp<50?100:90;case NODE_SHOP:return g->gold>130?140:45;case NODE_FIGHT:return 60;case NODE_ELITE:return hp>85?48:-100;default:return 10;}
}
static int selected_node(const Game*g){
 int best=-999,chosen=1;
 for(int j=0;j<3;j++)if(g->floor==0||abs(j-g->lane)<=1){int sc=node_score(g,g->map[g->floor][j]);if(sc>best){best=sc;chosen=j;}}
 return chosen;
}
static int card_rank(int raw){
 int id=CARD_ID(raw),up=CARD_UP(raw);
 static int scores[50]={35,20,46,63,58,36,50,46,65,42,49,54,55,65,49,35,70,76,35,52,64,70,70,65,44,65,56,45,65,45,43,60,57,73,71,55,70,65,70,60,45,70,54,67,65,85,32,60,74,63};
 return (id>=0&&id<50?scores[id]:0)+up*9;
}
static int expected_damage(const Game*g){int sum=0;for(int i=0;i<g->enemy_count;i++)if(g->enemies[i].hp>0){int in=g->enemies[i].intent;if(in==0||in==3)sum+=g->enemies[i].intent_value;if(in==2||in==5)sum+=g->enemies[i].intent_value/2;}return sum;}
static int choose_card(const Game*g){
 int chosen=-1,best=-10000,want_defense=expected_damage(g)>g->block;
 for(int i=0;i<g->hand_count;i++){
  int raw=g->hand[i],id=CARD_ID(raw),cost=cards[id].cost;
  if(cost==-2)continue;
  if(cost<0)cost=g->energy;
  if(cost>g->energy)continue;
  int score=card_rank(raw);
  if(cards[id].type==1)score+=(want_defense&&g->block<expected_damage(g)/2)?12:-80;
  if(cards[id].type==0)score+=35;
  if(id==0)score-=4;
  if(id==8||id==23||id==28||id==34||id==44)score+=40;
  if(id==6||id==18||id==29||id==43||id==46)score-=g->hp<30?60:0;
  if(cost==0)score+=30;
  if(score>best){best=score;chosen=i;}
 }
 return chosen;
}
static int run(int seed,int verbose){
 Game g;game_new(&g,seed);game_action(&g,BTN_OK);int fight_count=0,turns=0;
 for(int limit=0;limit<18000;limit++){
  if(g.screen==VICTORY||g.screen==DEFEAT)break;
  if(g.screen==MAP){if(g.floor==MAP_ROWS){game_action(&g,BTN_OK);}else{int lane=selected_node(&g);game_choose_node(&g,lane);}continue;}
  if(g.screen==COMBAT){
   if(g.turn>85){if(verbose)printf("stuck fight\n");return -1;}
   int card=choose_card(&g);
   if(card>=0){int enemy=0;for(int i=0;i<g.enemy_count;i++)if(g.enemies[i].hp>0){enemy=i;break;}game_play_card(&g,card,enemy);}
   else{game_end_turn(&g);turns++;}
   continue;
  }
  if(g.screen==REWARD){int best=-100,j=3;for(int i=0;i<3;i++){int rank=card_rank(g.reward[i]);if(rank>best){best=rank;j=i;}}g.selection=j;game_action(&g,BTN_OK);fight_count++;continue;}
  if(g.screen==BOSS_REWARD){g.selection=0;game_action(&g,BTN_OK);continue;}
  if(g.screen==SHOP){if(g.hp<g.maxhp-18&&g.gold>=45){g.selection=4;game_action(&g,BTN_OK);}if(g.gold>=155&&g.shop_relic>=0){g.selection=3;game_action(&g,BTN_OK);}g.selection=6;game_action(&g,BTN_OK);continue;}
  if(g.screen==REST){g.selection=0;game_action(&g,BTN_OK);continue;}
  if(g.screen==EVENT){g.selection=g.hp*2<g.maxhp?1:0;game_action(&g,BTN_OK);continue;}
  if(g.screen==DECK_VIEW){game_action(&g,BTN_BACK);continue;}
  if(g.screen==HELP){game_action(&g,BTN_BACK);continue;}
 }
 if(verbose)printf("seed %d: end=%d act=%d floor=%d hp=%d/%d relics=%d deck=%d fights=%d turns=%d\n",seed,g.screen,g.act,g.floor,g.hp,g.maxhp,g.relic_count,g.deck_count,fight_count,turns);
 return g.screen==VICTORY?3:g.act-1;
}
int main(void){int result[5]={0};for(int i=1;i<=1000;i++){int r=run(i,0);if(r>=0&&r<5)result[r]++;}printf("1000 heuristic-agent runs: defeated in act 1: %d, act 2: %d, act 3: %d, won: %d\n",result[0],result[1],result[2],result[3]);for(int i=1;i<=10;i++)run(i,1);}
