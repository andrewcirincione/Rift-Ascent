#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p screenshots/animation
# Animation-specific test instruments the full software renderer.
gcc -std=c11 -O1 -g -Wall -Wextra -Wno-misleading-indentation \
 -fsanitize=address,undefined -fno-omit-frame-pointer \
 src/game.c src/render.c src/artwork.c src/motion_art.c src/enemy_art.c src/sound.c \
 tests/animation_test.c -o /tmp/rift_animation_test
ASAN_OPTIONS=detect_leaks=1 /tmp/rift_animation_test
python3 - <<'PY'
from PIL import Image
from pathlib import Path
root=Path('screenshots/animation')
files=sorted(root.glob('*.ppm'))
frames=[Image.open(p).copy() for p in files]
frames[0].save('screenshots/animated_combat.gif',save_all=True,append_images=frames[1:],duration=34,loop=0,optimize=True)
print('Animation preview:',len(frames),'frames; GIF:',Path('screenshots/animated_combat.gif').stat().st_size,'bytes')
for p in files:p.unlink()
PY
