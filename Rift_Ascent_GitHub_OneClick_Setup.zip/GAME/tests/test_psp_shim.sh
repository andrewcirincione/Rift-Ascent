#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p /tmp/rift_psp_obj
gcc -std=c11 -O1 -Wall -Wextra -Werror -Itests/mock_psp -Dmain=psp_game_entry -c src/psp_main.c -o /tmp/rift_psp_obj/psp_main.o
gcc -std=c11 -O1 -Wall -Wextra -fsanitize=address,undefined -fno-omit-frame-pointer -c src/game.c -o /tmp/rift_psp_obj/game.o
gcc -std=c11 -O1 -Wall -Wextra -fsanitize=address,undefined -fno-omit-frame-pointer -c src/render.c -o /tmp/rift_psp_obj/render.o
gcc -std=c11 -O1 -Wall -Wextra -fsanitize=address,undefined -fno-omit-frame-pointer -c src/artwork.c -o /tmp/rift_psp_obj/artwork.o
gcc -std=c11 -O1 -Wall -Wextra -fsanitize=address,undefined -fno-omit-frame-pointer -c src/motion_art.c -o /tmp/rift_psp_obj/motion_art.o
gcc -std=c11 -O1 -Wall -Wextra -fsanitize=address,undefined -fno-omit-frame-pointer -c src/enemy_art.c -o /tmp/rift_psp_obj/enemy_art.o
gcc -std=c11 -O1 -Wall -Wextra -fsanitize=address,undefined -fno-omit-frame-pointer -c src/sound.c -o /tmp/rift_psp_obj/sound.o
gcc -std=c11 -O1 -Wall -Wextra -fsanitize=address,undefined -fno-omit-frame-pointer -c tests/mock_psp_api.c -o /tmp/rift_psp_obj/mock.o
gcc -fsanitize=address,undefined /tmp/rift_psp_obj/*.o -o /tmp/rift_psp_smoke
ASAN_OPTIONS=detect_leaks=1 /tmp/rift_psp_smoke
echo 'PASS: PSP front end executes 14 frames against mocked firmware, VRAM address verified.'
