from PIL import Image,ImageDraw,ImageFont,ImageEnhance
from pathlib import Path
p=Path(__file__).resolve().parent.parent/'assets';p.mkdir(exist_ok=True)
# XMB ICON0.PNG 144x80 - layered hand drawn pixel poster, copyright-original.
s=4
im=Image.new('RGB',(144*s,80*s));d=ImageDraw.Draw(im)
for y in range(80*s):
 t=y/(80*s)
 d.line((0,y,144*s,y),fill=(round(9+10*t),round(16+8*t),round(28+9*t)))
D=lambda a:tuple(int(i*s) for i in a)
d.polygon([D((70,72)),D((114,7)),D((148,72))],fill=(31,39,51))
d.polygon([D((83,66)),D((113,0)),D((144,66))],fill=(43,49,61))
d.rectangle(D((107,14,122,73)),fill=(70,72,73))
for y in (23,43,63):d.rectangle(D((114,y,118,y+7)),fill=(225,107,63))
d.polygon([D((21,74)),D((29,36)),D((38,73))],fill=(113,50,47))
d.polygon([D((22,52)),D((28,31)),D((35,52))],fill=(148,142,117))
d.rectangle(D((26,48,31,56)),fill=(46,44,46))
d.line([D((31,62)),D((57,12))],fill=(219,177,105),width=2*s)
d.polygon([D((53,16)),D((63,2)),D((56,20))],fill=(190,190,177))
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',11*s)
font2=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',6*s)
d.text(D((4,5)),'RIFT',font=font,fill=(242,196,114),stroke_width=0)
d.text(D((4,18)),'ASCENT',font=font,fill=(239,224,201))
d.text(D((4,67)),'ONE WARRIOR. THREE ACTS.',font=font2,fill=(219,190,150))
d.rectangle((0,0,144*s-1,80*s-1),outline=(211,157,93),width=3*s)
im.resize((144,80),Image.Resampling.LANCZOS).save(p/'ICON0.PNG')
# PSP XMB background original in-game artwork.
screen=Image.open(Path(__file__).resolve().parent.parent/'screenshots'/'01_title.png').convert('RGB')
screen.save(p/'PIC1.PNG')
print('Generated ICON0.PNG and PIC1.PNG')
