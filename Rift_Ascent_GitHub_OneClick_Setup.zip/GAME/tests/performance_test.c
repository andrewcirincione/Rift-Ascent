#include "../src/game.h"
#include "../src/sound.h"
#include <stdio.h>
#include <time.h>
#include <assert.h>
#include <stdint.h>
static uint32_t framebuffer[512*H];
static int16_t pcm[512*2];
static long elapsed_ns(struct timespec a,struct timespec b){
 return (b.tv_sec-a.tv_sec)*1000000000L+(b.tv_nsec-a.tv_nsec);
}
int main(void){
 Game g;game_new(&g,4275);game_action(&g,BTN_OK);game_action(&g,BTN_OK);assert(g.screen==COMBAT);
 RiftSound music={0};struct timespec begin,end;
 clock_gettime(CLOCK_MONOTONIC,&begin);
 for(unsigned i=0;i<360;i++){
  game_render_frame(&g,framebuffer,512,i);
  rift_audio_generate(&music,pcm,512,1,0);
 }
 clock_gettime(CLOCK_MONOTONIC,&end);
 double ms=(double)elapsed_ns(begin,end)/360000000.0;
 printf("HOST (not PSP): 360 480x272 animated combat frames + audio blocks; mean %.2f ms/frame; %.1f fps equivalent\n",ms,1000.0/ms);
 return 0;
}
