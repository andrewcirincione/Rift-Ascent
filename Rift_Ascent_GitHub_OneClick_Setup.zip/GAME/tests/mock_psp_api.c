#include <assert.h>
#include <setjmp.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "mock_psp/pspkernel.h"
#include "mock_psp/pspctrl.h"
#include "mock_psp/pspdisplay.h"
#include "mock_psp/pspge.h"
#include "mock_psp/psppower.h"
#include "mock_psp/pspaudio.h"
#include "../src/game.h"
static uint32_t edram[512*H*2];
static jmp_buf stop;
static int frames=0,nonzero=0,display_calls=0,fail_stage=0,exit_calls=0;
int psp_game_entry(int argc,char**argv);
int sceAudioChReserve(int ch,int n,int fmt){assert(ch==-1&&n==512&&fmt==0);return 0;}
int sceAudioChRelease(int ch){assert(ch==0);return 0;}
int sceAudioOutputBlocking(int ch,int volume,void*buf){assert(ch==0&&volume>0&&buf!=NULL);return 512;}
int sceKernelCreateCallback(const char*n,int (*cb)(int,int,void*),void*ctx){(void)n;(void)cb;(void)ctx;return 1;}
int sceKernelRegisterExitCallback(int id){(void)id;return 0;}
int sceKernelSleepThreadCB(void){return 0;}
int sceKernelCreateThread(const char*n,int (*thread)(SceSize,void*),int pri,int stack,int attr,void*ctx){(void)n;(void)thread;(void)pri;(void)stack;(void)attr;(void)ctx;return 1;}
int sceKernelStartThread(int id,int args,void*arg){(void)id;(void)args;(void)arg;return 0;}
int sceKernelWaitThreadEnd(int id,int *result){(void)id;(void)result;return 0;}
int sceKernelDeleteThread(int id){(void)id;return 0;}
void sceKernelExitGame(void){exit_calls++;}
unsigned int sceKernelGetSystemTimeLow(void){return 3577111u;}
void sceKernelDcacheWritebackAll(void){}
void sceCtrlSetSamplingCycle(int n){assert(n==0);}
void sceCtrlSetSamplingMode(int n){assert(n==0);}
int sceCtrlPeekBufferPositive(SceCtrlData*pad,int n){assert(n==1);pad->Buttons=frames==0?PSP_CTRL_CROSS:0;return n;}
int scePowerSetClockFrequency(int cpu,int ram,int bus){assert(cpu==333&&ram==333&&bus==166);return 0;}
void*sceGeEdramGetAddr(void){return edram;}
unsigned int sceGeEdramGetSize(void){return fail_stage==1?512u:sizeof(edram);}
int sceDisplaySetMode(int mode,int w,int h){assert(mode==0&&w==480&&h==272);return fail_stage==2?-1:0;}
int sceDisplaySetFrameBuf(void*ptr,int stride,int format,int sync){
 assert(ptr!=NULL);assert(stride==512&&format==3&&(sync==0||sync==1));
 if(fail_stage==3)return -1;
 uintptr_t p=(uintptr_t)ptr,lo=(uintptr_t)edram,hi=(uintptr_t)(edram+512*H*2);
 assert(p>=lo&&p<hi);
 display_calls++;
 for(size_t i=0;i<512*H*2;i++)if(edram[i]){nonzero++;break;}
 return 0;
}
int sceDisplayWaitVblankStart(void){frames++;if(frames==14)longjmp(stop,1);return 0;}
int main(void){
 if(!setjmp(stop))psp_game_entry(0,NULL);
 assert(frames==14);assert(nonzero>0);assert(display_calls>2);
 /* Deliberately broken EDRAM/display APIs must abort before rendering. */
 for(fail_stage=1;fail_stage<=3;fail_stage++){
  int old_exit=exit_calls,old_frames=frames;
  assert(psp_game_entry(0,NULL)==1);
  assert(exit_calls==old_exit+1&&frames==old_frames);
 }
 return 0;
}
