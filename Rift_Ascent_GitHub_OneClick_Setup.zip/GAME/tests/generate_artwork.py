#!/usr/bin/env python3
"""Create PSP-native RGB565 artwork from the game's original illustrated concepts.
Assets are embedded in the executable: no runtime file access, PNG decoder or texture API.
Source artwork must be supplied to this script (see README). Existing generated C file
is committed in the release archive so PSPSDK builds do not need Python/Pillow.
"""
from PIL import Image, ImageOps, ImageEnhance, ImageFilter, ImageDraw
from pathlib import Path
import struct
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'assets'/'runtime'
OUT.mkdir(parents=True,exist_ok=True)
SOURCE=ROOT/'assets'/'source'
SOURCE_FILES={
 'title':'title.png',
 'battle':'battle.png',
 'map':'map.png',
 'reward':'reward.png'}
for f in SOURCE_FILES.values():
 if not (SOURCE/f).exists():
  raise SystemExit(f'Missing original source artwork: {SOURCE/f}')

def tone(im, brightness=0.8, contrast=1.08, saturation=1.12):
 im=ImageEnhance.Color(im.convert('RGB')).enhance(saturation)
 im=ImageEnhance.Contrast(im).enhance(contrast)
 return ImageEnhance.Brightness(im).enhance(brightness)

def fill_gradient(xy, size, direction='horizontal'):
 pass

# Dark fantasy art with a clear area for actual dynamic game menus.
raw=Image.open(SOURCE/SOURCE_FILES['title']).convert('RGB')
title=tone(raw.resize((480,272),Image.Resampling.LANCZOS),0.81)
# The concept illustration includes noninteractive menu options: obscure those and
# paint our *functional* game menu on top in C.
mask=Image.new('L',(480,272));d=ImageDraw.Draw(mask)
for k in range(18):
 alpha=10+int(k*7.5)
 d.rounded_rectangle((173-k//4,124-k//3,311+k//4,245+k//3),radius=12,fill=alpha)
blur=title.filter(ImageFilter.GaussianBlur(18))
title=Image.composite(blur,title,mask)
overlay=Image.new('RGB',title.size,(9,16,27));a=Image.new('L',title.size);d=ImageDraw.Draw(a)
d.rounded_rectangle((176,124,310,247),radius=9,fill=200)
title=Image.composite(overlay,title,a)

# PSP combat plays over an actual illustrated battlefield with two figures.
# Crop excludes concept HUD and card hand; those are drawn dynamically by game_render.
battle=raw # replace below
rawb=Image.open(SOURCE/SOURCE_FILES['battle']).convert('RGB')
battle=tone(rawb.crop((0,138,1672,570)).resize((480,167),Image.Resampling.LANCZOS),0.83,1.13,1.05)
# Remove baked numbers from the art's bottom strip while preserving the character art.
# The game's actual dynamic health bars and intents will be layered over this.
mask=Image.new('L',battle.size); d=ImageDraw.Draw(mask)
for y in range(132,167):
 d.rectangle((0,y,480,y),fill=min(255, int((y-132)*7.5)))
blurred=battle.filter(ImageFilter.GaussianBlur(13))
battle=Image.composite(blurred,battle,mask)
# Allocate top 33 pixels for the dynamic header, and bottom 72 for cards.
combat_bg=Image.new('RGB',(480,272),(11,19,31));combat_bg.paste(battle,(0,31))
# A small portion of bottom architecture continues under the battle panel.
combat_bg.paste(battle.crop((0,130,480,167)).resize((480,75)),(0,197))
combat_bg=tone(combat_bg,0.93)

rawm=Image.open(SOURCE/SOURCE_FILES['map']).convert('RGB')
mapbg=tone(rawm.resize((480,272),Image.Resampling.LANCZOS),0.68,1.1)
# Handmade parchment texture sampled from original illustration, without fixed map nodes.
# Using blended parchment + original texture prevents the mockup map from being hardcoded.
parchment=Image.new('RGB',(295,198),(153,124,91))
pp=parchment.load()
for y in range(198):
 for x in range(295):
  noise= ((x*13+y*37+x*y*3)%43)-22
  v=int(noise*.43)
  edge=max(0,30-min(x,y,294-x,197-y)*3)
  pp[x,y]=(max(0,153+v-edge),max(0,125+v-edge),max(0,93+v-edge))
parchment=parchment.filter(ImageFilter.GaussianBlur(.6))
mapbg.paste(parchment,(18,46))

rawr=Image.open(SOURCE/SOURCE_FILES['reward']).convert('RGB')
rewardbg=tone(rawr.resize((480,272),Image.Resampling.LANCZOS),0.53,1.13)
# The original is a staged UI mockup; mask its preset cards and labels so
# reward choices are always generated live by game logic.
panel=Image.new('RGB',(480,272),(11,19,30));alpha=Image.new('L',(480,272));d=ImageDraw.Draw(alpha)
d.rounded_rectangle((41,47,443,249),radius=12,fill=222)
rewardbg=Image.composite(panel,rewardbg,alpha)

# Interior panels on event/shop/deck/rest/boss screens share the atmospheric ruins.
menubg=tone(rawb.crop((0,75,1672,941)).resize((480,272),Image.Resampling.LANCZOS),0.39,1.06)
# Save visual assets so the user can inspect the *actual PSP-target graphics*.
images={'title_bg':title,'combat_bg':combat_bg,'map_bg':mapbg,
        'reward_bg':rewardbg,'menu_bg':menubg}
# Large 2D illustrations cropped from generated Rift Ascent card reward art.
regions={'art_strike':(1030,362,1327,571), 'art_block':(704,358,969,572),
         'art_power':(360,362,640,572), 'art_curse':(1040,356,1324,570)}
for name,box in regions.items():
 im=rawr.crop(box).resize((100,60),Image.Resampling.LANCZOS)
 if name=='art_curse':im=ImageOps.colorize(ImageOps.grayscale(im),(25,17,40),(167,75,196))
 images[name]=tone(im,1.05,1.1)
for name,im in images.items():im.save(OUT/(name+'.png'))

# Header + source generated as little-endian RGB565 values. Runtime arrays are read
# directly by PSP (MIPS little-endian), and expanded to the existing 8888 framebuffer.
with open(ROOT/'src'/'artwork.h','w') as f:
 f.write('/* Auto-generated, compact RGB565 artwork for PSP. Do not edit manually. */\n#ifndef RA_ARTWORK_H\n#define RA_ARTWORK_H\n#include <stdint.h>\n')
 for name,im in images.items():
  w,h=im.size
  f.write(f'extern const uint16_t ra_{name}[{w*h}];\n#define RA_{name.upper()}_W {w}\n#define RA_{name.upper()}_H {h}\n')
 f.write('#endif\n')
with open(ROOT/'src'/'artwork.c','w') as f:
 f.write('#include "artwork.h"\n/* Authored illustration assets, RGB565, embedded into EBOOT.PBP. */\n')
 for name,im in images.items():
  pixels=list(im.getdata());w,h=im.size
  f.write(f'const uint16_t ra_{name}[{w*h}] __attribute__((aligned(16))) = {{\n')
  for i in range(0,len(pixels),16):
   def rgb565(p):r,g,b=p[:3];return ((r>>3)<<11)|((g>>2)<<5)|(b>>3)
   f.write('  '+','.join(f'0x{rgb565(p):04x}' for p in pixels[i:i+16])+',\n')
  f.write('};\n')
print('Generated',len(images),'runtime image assets; source size', (ROOT/'src'/'artwork.c').stat().st_size)
