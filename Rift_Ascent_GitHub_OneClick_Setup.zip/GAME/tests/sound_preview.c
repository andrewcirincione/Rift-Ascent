#include "../src/sound.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
int main(void){
 FILE*f=fopen("assets/SOUNDTRACK_PREVIEW.wav","wb");if(!f)return 1;
 unsigned int frames=44100*6,data_size=frames*4,filesize=36+data_size;
 fwrite("RIFF",1,4,f);fwrite(&filesize,4,1,f);fwrite("WAVEfmt ",1,8,f);
 unsigned int sixteen=16,rate=44100,byterate=44100*4;
 unsigned short format=1,channels=2,align=4,bits=16;
 fwrite(&sixteen,4,1,f);fwrite(&format,2,1,f);fwrite(&channels,2,1,f);
 fwrite(&rate,4,1,f);fwrite(&byterate,4,1,f);fwrite(&align,2,1,f);fwrite(&bits,2,1,f);
 fwrite("data",1,4,f);fwrite(&data_size,4,1,f);
 RiftSound snd={0};int16_t buf[512*2];
 for(unsigned int i=0;i<frames;){int n=frames-i>512?512:frames-i;rift_audio_generate(&snd,buf,n,1,0);fwrite(buf,4,n,f);i+=(unsigned int)n;}
 fclose(f);puts("Generated 6-second preview WAV");return 0;
}
