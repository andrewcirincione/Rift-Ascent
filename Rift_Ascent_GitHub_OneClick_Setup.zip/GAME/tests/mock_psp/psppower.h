#ifndef MOCK_PSPPOWER_H
#define MOCK_PSPPOWER_H
int scePowerSetClockFrequency(int,int,int);
#endif
