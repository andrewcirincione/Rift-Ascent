#ifndef MOCK_PSPAUDIO_H
#define MOCK_PSPAUDIO_H
#define PSP_AUDIO_FORMAT_STEREO 0
int sceAudioChReserve(int,int,int);
int sceAudioChRelease(int);
int sceAudioOutputBlocking(int,int,void*);
#endif
