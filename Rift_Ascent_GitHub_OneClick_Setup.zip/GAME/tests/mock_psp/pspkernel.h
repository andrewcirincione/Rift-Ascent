#ifndef MOCK_PSPKERNEL_H
#define MOCK_PSPKERNEL_H
#include <stdint.h>
#include <stddef.h>
typedef uint32_t SceSize;
#define PSP_MODULE_USER 0
#define THREAD_ATTR_USER 0x80000000u
#define THREAD_ATTR_VFPU 0x4000u
#define PSP_MODULE_INFO(name,attr,maj,min) static const char mock_module_info[] __attribute__((unused))=name
#define PSP_MAIN_THREAD_ATTR(attr) static unsigned int mock_main_attr __attribute__((unused))=(attr)
int sceKernelCreateCallback(const char*,int (*cb)(int,int,void*),void*);
int sceKernelRegisterExitCallback(int);
int sceKernelSleepThreadCB(void);
int sceKernelCreateThread(const char*,int (*thread)(SceSize,void*),int,int,int,void*);
int sceKernelStartThread(int,int,void*);
int sceKernelWaitThreadEnd(int,int*);
int sceKernelDeleteThread(int);
void sceKernelExitGame(void);
unsigned int sceKernelGetSystemTimeLow(void);
void sceKernelDcacheWritebackAll(void);
#endif
