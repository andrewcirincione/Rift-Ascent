#ifndef MOCK_PSPGE_H
#define MOCK_PSPGE_H
void *sceGeEdramGetAddr(void);
unsigned int sceGeEdramGetSize(void);
#endif
