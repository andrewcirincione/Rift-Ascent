#ifndef MOCK_PSPDISPLAY_H
#define MOCK_PSPDISPLAY_H
#define PSP_DISPLAY_MODE_LCD 0
#define PSP_DISPLAY_PIXEL_FORMAT_8888 3
#define PSP_DISPLAY_SETBUF_IMMEDIATE 0
#define PSP_DISPLAY_SETBUF_NEXTFRAME 1
int sceDisplaySetMode(int,int,int);
int sceDisplaySetFrameBuf(void*,int,int,int);
int sceDisplayWaitVblankStart(void);
#endif
