#ifndef MOCK_PSPCTRL_H
#define MOCK_PSPCTRL_H
#include <stdint.h>
typedef struct{unsigned int Buttons;}SceCtrlData;
#define PSP_CTRL_CROSS 0x4000
#define PSP_CTRL_CIRCLE 0x2000
#define PSP_CTRL_SQUARE 0x8000
#define PSP_CTRL_TRIANGLE 0x1000
#define PSP_CTRL_LEFT 0x80
#define PSP_CTRL_RIGHT 0x20
#define PSP_CTRL_UP 0x10
#define PSP_CTRL_DOWN 0x40
#define PSP_CTRL_START 0x8
#define PSP_CTRL_MODE_DIGITAL 0
void sceCtrlSetSamplingCycle(int);
void sceCtrlSetSamplingMode(int);
int sceCtrlPeekBufferPositive(SceCtrlData*,int);
#endif
