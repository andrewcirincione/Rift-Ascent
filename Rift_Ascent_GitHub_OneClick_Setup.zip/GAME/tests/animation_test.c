#include "../src/game.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <time.h>

static uint32_t canvas_a[512*H+64],canvas_b[512*H+64],canvas_first[512*H+64];
static void saveppm(const char *filename,const uint32_t *data){
 FILE*f=fopen(filename,"wb");assert(f);
 fprintf(f,"P6\n%d %d\n255\n",W,H);
 for(int y=0;y<H;y++)for(int x=0;x<W;x++){
  uint32_t color=data[y*512+x];
  fputc(color&255,f);fputc((color>>8)&255,f);fputc((color>>16)&255,f);
 }
 fclose(f);
}
static long pixel_difference(const uint32_t*a,const uint32_t*b,int x0,int y0,int x1,int y1){
 long sum=0;
 for(int y=y0;y<y1;y++)for(int x=x0;x<x1;x++)if(a[y*512+x]!=b[y*512+x])sum++;
 return sum;
}
int main(void){
 Game g;game_new(&g,4671);game_action(&g,BTN_OK);
 assert(g.screen==MAP);
 g.selection=1;game_action(&g,BTN_OK);
 assert(g.screen==COMBAT);
 memset(canvas_a,0xa5,sizeof(canvas_a));memset(canvas_b,0xa5,sizeof(canvas_b));
 game_render_frame(&g,canvas_a,512,0);
 game_render_frame(&g,canvas_b,512,34);
 assert(pixel_difference(canvas_a,canvas_b,0,47,179,175)>100);
 assert(pixel_difference(canvas_a,canvas_b,300,47,412,175)>20);
 assert(pixel_difference(canvas_a,canvas_b,0,180,470,252)>10);
 /* Neither animation nor HUD rendering writes into the stride padding. */
 for(int y=0;y<H;y++)for(int x=W;x<512;x++){
  assert(canvas_a[y*512+x]==0xa5a5a5a5u);
  assert(canvas_b[y*512+x]==0xa5a5a5a5u);
 }
 /* Render a continuous 1 second cinematic event at the target screen size. */
 game_effect_start(1,4);
 char path[150];
 for(unsigned f=0;f<36;f++){
  game_render_frame(&g,canvas_a,512,f);
  if(f==0)memcpy(canvas_first,canvas_a,sizeof(canvas_first));
  sprintf(path,"screenshots/animation/%03u.ppm",f);
  saveppm(path,canvas_a);
 }
 long diff=pixel_difference(canvas_a,canvas_first,0,0,W,H);
 assert(diff>100);
 puts("PASS: animated sprite movement, independent enemy movement, energy/card motion, particle and hit effects; framebuffer bounds guarded");
 return 0;
}
