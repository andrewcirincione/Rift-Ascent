#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 tests/test_eboot_verifier.py
# Exhaustive roster, combat move, and exclusive boss-pool checks.
gcc -std=c11 -O1 -g -Wall -Wextra -fsanitize=address,undefined -fno-omit-frame-pointer src/game.c tests/roster_test.c -o /tmp/rift_roster_test
ASAN_OPTIONS=detect_leaks=1 /tmp/rift_roster_test
python3 tests/asset_audit.py
./test.sh
./tests/test_psp_shim.sh
./tests/cross_check.sh
./tests/animation_test.sh
gcc -std=c11 -O2 -Wall -Wextra -Wno-misleading-indentation src/game.c tests/ai_playtest.c -o /tmp/rift_playtest
/tmp/rift_playtest | head -1
gcc -std=gnu11 -O2 -Wno-misleading-indentation src/game.c src/render.c src/artwork.c src/motion_art.c src/enemy_art.c src/sound.c tests/performance_test.c -o /tmp/rift_render_perf
/tmp/rift_render_perf
echo 'All tests available in this environment have completed.'
