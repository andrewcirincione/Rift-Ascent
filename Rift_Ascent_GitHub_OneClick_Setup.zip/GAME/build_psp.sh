#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v psp-config >/dev/null || ! command -v psp-gcc >/dev/null; then
  echo 'ERROR: Official PSPDEV/PSPSDK compiler is not installed or in PATH.' >&2
  exit 1
fi
# Reject stale output even when make or package verification fails.
rm -f EBOOT.PBP
make clean
make -j2
python3 verify_eboot.py EBOOT.PBP
printf 'Built and structurally verified: %s\n' "$(pwd)/EBOOT.PBP"
