@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CREATE_PRIVATE_REPO_AND_BUILD.ps1"
set "ret=%ERRORLEVEL%"
echo.
if not "%ret%"=="0" echo Setup or build failed (exit code %ret%). See the error above.
pause
exit /b %ret%
