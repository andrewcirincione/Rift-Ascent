# Rift Ascent - PSPDEV native build repository

This repository contains the actual Rift Ascent game engine, PSP backend, embedded graphics, sound, and package validator.

**GitHub Actions:** Every push and manual workflow dispatch runs `.github/workflows/psp-build.yml`, compiling with the PSPDEV `v20261001` Docker image and uploading `Rift-Ascent-EBOOT` if native compilation and `verify_eboot.py` succeed. A green compilation does **not** establish that PPSSPP or PSP hardware can launch the EBOOT.

**Upload directions:** Create a private GitHub repository, extract this ZIP, and upload all extracted contents, including the hidden `.github` directory and the `GAME` folder, to the repository root. Grant the ChatGPT GitHub integration access to that repository so it can inspect the Actions logs and propose fixes.

The release file is in the Actions run's *Artifacts* area, not the GitHub source tree.
