# Rift Ascent: GitHub repository + PSPDEV EBOOT build (Windows)
# Requires an explicit GitHub browser authorization; no credentials are stored by this script.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$ProgressPreference = 'SilentlyContinue'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

function Say([string]$message) { Write-Host "`n==> $message" -ForegroundColor Cyan }
function Fail([string]$message) { throw $message }

function Find-Exe([string]$name, [string[]]$paths) {
  $command = Get-Command $name -ErrorAction SilentlyContinue
  if ($command) { return $command.Source }
  foreach ($p in $paths) { if (Test-Path -LiteralPath $p) { return $p } }
  return $null
}

function Ensure-Tool([string]$name, [string]$wingetId, [string[]]$knownPaths) {
  $candidate = Find-Exe $name $knownPaths
  if ($candidate) { return $candidate }
  Say "Installing $wingetId with Windows Package Manager"
  if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    Fail "Windows Package Manager (winget) is unavailable. Install Git and GitHub CLI, then rerun."
  }
  & winget install --id $wingetId -e --source winget --accept-package-agreements --accept-source-agreements --silent
  if ($LASTEXITCODE -ne 0) { Fail "Installation of $wingetId failed (exit $LASTEXITCODE)." }
  $candidate = Find-Exe $name $knownPaths
  if (-not $candidate) { Fail "$wingetId installed but executable isn't available. Restart Windows and rerun." }
  return $candidate
}

try {
  Say 'Checking tools'
  $git = Ensure-Tool 'git.exe' 'Git.Git' @('C:\Program Files\Git\cmd\git.exe', 'C:\Program Files (x86)\Git\cmd\git.exe')
  $gh = Ensure-Tool 'gh.exe' 'GitHub.cli' @('C:\Program Files\GitHub CLI\gh.exe', 'C:\Program Files (x86)\GitHub CLI\gh.exe')

  Say 'Checking GitHub authorization'
  $oldPref = $ErrorActionPreference
  $ErrorActionPreference = 'Continue'
  try { & $gh auth status --hostname github.com *> $null; $authorized = ($LASTEXITCODE -eq 0) }
  finally { $ErrorActionPreference = $oldPref }
  if (-not $authorized) {
    Write-Host 'Your browser will ask you to authorize GitHub CLI. This approval cannot be done for you.' -ForegroundColor Yellow
    & $gh auth login --hostname github.com --git-protocol https --web
    if ($LASTEXITCODE -ne 0) { Fail 'GitHub login was not completed.' }
  }
  & $gh auth setup-git
  if ($LASTEXITCODE -ne 0) { Fail 'GitHub git credential setup failed.' }

  $owner = (& $gh api user --jq '.login' | Out-String).Trim()
  if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($owner)) { Fail 'Could not read your GitHub username.' }
  $repo = "$owner/rift-ascent-psp"
  Say "Checking private repository $repo"
  $oldPref = $ErrorActionPreference
  $ErrorActionPreference = 'Continue'
  try { & $gh repo view $repo --json name --jq '.name' *> $null; $alreadyExists = ($LASTEXITCODE -eq 0) }
  finally { $ErrorActionPreference = $oldPref }
  if ($alreadyExists) {
    Fail "Repository $repo already exists. This bootstrap refuses to overwrite an existing repository."
  }
  if (Test-Path -LiteralPath (Join-Path $root '.git')) {
    Fail 'The package folder already contains a .git directory. Extract a fresh copy to prevent accidental pushes.'
  }

  Say 'Initializing project repository'
  & $git init -b main
  if ($LASTEXITCODE -ne 0) { Fail 'git init failed.' }
  & $git add --all
  if ($LASTEXITCODE -ne 0) { Fail 'git add failed.' }
  & $git -c user.name='Rift Ascent Build' -c user.email='rift-ascent-build@users.noreply.github.com' commit -m 'Add complete Rift Ascent PSP game and PSPDEV build workflow'
  if ($LASTEXITCODE -ne 0) { Fail 'git commit failed.' }

  Say "Creating private GitHub repository $repo and uploading source"
  & $gh repo create $repo --private --source $root --remote origin --push
  if ($LASTEXITCODE -ne 0) { Fail 'GitHub repository creation or source upload failed.' }

  $repoUrl = "https://github.com/$repo"
  Say 'Waiting for the native PSPDEV build to appear'
  Write-Host "Repo: $repoUrl"
  $runId = ''
  for ($i=0; $i -lt 30; $i++) {
    $oldPref = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try { $result = (& $gh run list --repo $repo --workflow psp-build.yml --limit 1 --json databaseId --jq '.[0].databaseId' 2>$null | Out-String).Trim(); $listOk = ($LASTEXITCODE -eq 0) }
    finally { $ErrorActionPreference = $oldPref }
    if ($listOk -and $result -match '^\d+$') { $runId = $result; break }
    Start-Sleep -Seconds 4
  }
  if (-not $runId) {
    Fail "Repository was uploaded, but the build has not appeared yet. Open $repoUrl/actions to see its status."
  }

  Say "Watching official PSP compiler workflow #$runId"
  & $gh run watch $runId --repo $repo --exit-status --interval 5
  if ($LASTEXITCODE -ne 0) {
    Write-Host "Compiler logs: $repoUrl/actions/runs/$runId" -ForegroundColor Red
    Fail 'The PSPDEV build failed. The workflow logs contain compiler errors.'
  }
  Say 'Downloading built EBOOT.PBP'
  $output = Join-Path $root 'OUTPUT'
  New-Item -ItemType Directory -Force -Path $output | Out-Null
  & $gh run download $runId --repo $repo --name 'Rift-Ascent-EBOOT' --dir $output
  if ($LASTEXITCODE -ne 0) { Fail 'Build passed but artifact download failed.' }
  $eboot = Join-Path $output 'EBOOT.PBP'
  if (-not (Test-Path -LiteralPath $eboot)) { Fail 'Workflow artifact did not contain an EBOOT.PBP.' }
  $item = Get-Item -LiteralPath $eboot
  if ($item.Length -lt 1024) { Fail 'EBOOT.PBP was unexpectedly small.' }
  Say 'NATIVE COMPILATION SUCCESSFUL'
  Write-Host "EBOOT file: $eboot" -ForegroundColor Green
  Write-Host "Build report: $repoUrl/actions/runs/$runId"
  Write-Host 'Note: successful compilation does not prove PSP/PPSSPP runtime compatibility.' -ForegroundColor Yellow
}
catch {
  Write-Host "`nERROR: $($_.Exception.Message)" -ForegroundColor Red
  exit 1
}
