# Rift Ascent — One-click GitHub cloud build

Windows: extract **all files** in this ZIP, then double-click `CREATE_PRIVATE_REPO_AND_BUILD.cmd`.

The script tries to install Git and GitHub CLI if missing, opens browser login if GitHub needs authorization, creates a **private** repository named `rift-ascent-psp`, pushes the complete source including `.github/workflows/psp-build.yml`, waits for the official PSPDEV GitHub Actions compile, and downloads `OUTPUT/EBOOT.PBP` if the build succeeds.

**What you must do:** Approve the GitHub CLI browser login the first time. Your account's GitHub integration/ChatGPT repository access may also need granting separately if you want ChatGPT to inspect private build logs and commit fixes.

**What it cannot guarantee:** PSPDEV compiler errors or PPSSPP/PSP runtime compatibility; the script reports failures and won't pass off a stale binary as a successful build.

If the build fails, its logs are at `https://github.com/YOUR_USERNAME/rift-ascent-psp/actions`.

The script refuses to overwrite an existing repository and creates a private repository by default.
